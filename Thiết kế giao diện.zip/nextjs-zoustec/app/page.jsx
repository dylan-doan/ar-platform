import Link from 'next/link';
import { Icon } from '../components/Icon';

export default function Home() {
  return (
    <main style={{ maxWidth: 1160, margin: '0 auto', padding: '72px 32px 80px' }}>
      <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: '.14em', textTransform: 'uppercase', color: '#6FCDE8', marginBottom: 14 }}>Zoustec · 產品介面系統</div>
      <h1 style={{ margin: 0, fontSize: 48, lineHeight: 1.06, letterSpacing: '-0.03em', fontWeight: 800, color: '#fff', maxWidth: '18ch' }}>AR 集章互動體驗平台</h1>
      <p style={{ margin: '18px 0 0', fontSize: 17, lineHeight: 1.6, color: '#B6D4DE', maxWidth: '58ch' }}>白標 SaaS 平台，快速建立活動網站，結合互動任務、WebAR 與 AI 3D 內容生成。以下為 6 個核心畫面。</p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill,minmax(320px,1fr))', gap: 18, marginTop: 40 }}>
          <Link href="/dashboard" style={{ display: 'block', textDecoration: 'none', background: 'rgba(255,255,255,.04)', border: '1px solid rgba(255,255,255,.1)', borderRadius: 16, padding: 24 }}>
            <span style={{ width: 48, height: 48, borderRadius: 12, background: 'linear-gradient(145deg,#38B0D6,#0E7490)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24 }}><Icon name="layout-dashboard" /></span>
            <div style={{ color: '#fff', fontWeight: 800, fontSize: 19, marginTop: 16 }}>客戶管理後台</div>
            <div style={{ color: '#8FB6C2', fontSize: 14, marginTop: 6, lineHeight: 1.5 }}>活動、任務與即時統計儀表板</div>
          </Link>
          <Link href="/builder" style={{ display: 'block', textDecoration: 'none', background: 'rgba(255,255,255,.04)', border: '1px solid rgba(255,255,255,.1)', borderRadius: 16, padding: 24 }}>
            <span style={{ width: 48, height: 48, borderRadius: 12, background: 'linear-gradient(145deg,#38B0D6,#0E7490)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24 }}><Icon name="layout-template" /></span>
            <div style={{ color: '#fff', fontWeight: 800, fontSize: 19, marginTop: 16 }}>活動網站產生器</div>
            <div style={{ color: '#8FB6C2', fontSize: 14, marginTop: 6, lineHeight: 1.5 }}>選範本、拖放編輯、匯出前端範本</div>
          </Link>
          <Link href="/ar-studio" style={{ display: 'block', textDecoration: 'none', background: 'rgba(255,255,255,.04)', border: '1px solid rgba(255,255,255,.1)', borderRadius: 16, padding: 24 }}>
            <span style={{ width: 48, height: 48, borderRadius: 12, background: 'linear-gradient(145deg,#38B0D6,#0E7490)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24 }}><Icon name="sparkles" /></span>
            <div style={{ color: '#fff', fontWeight: 800, fontSize: 19, marginTop: 16 }}>AI 3D 生成工具</div>
            <div style={{ color: '#8FB6C2', fontSize: 14, marginTop: 6, lineHeight: 1.5 }}>上傳 2D 圖，AI 生成 3D 並匯出 WebAR</div>
          </Link>
          <Link href="/experience" style={{ display: 'block', textDecoration: 'none', background: 'rgba(255,255,255,.04)', border: '1px solid rgba(255,255,255,.1)', borderRadius: 16, padding: 24 }}>
            <span style={{ width: 48, height: 48, borderRadius: 12, background: 'linear-gradient(145deg,#38B0D6,#0E7490)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24 }}><Icon name="scan-line" /></span>
            <div style={{ color: '#fff', fontWeight: 800, fontSize: 19, marginTop: 16 }}>WebAR 體驗 (LINE LIFF)</div>
            <div style={{ color: '#8FB6C2', fontSize: 14, marginTop: 6, lineHeight: 1.5 }}>參與者任務、AR 掃描與集章</div>
          </Link>
          <Link href="/console" style={{ display: 'block', textDecoration: 'none', background: 'rgba(255,255,255,.04)', border: '1px solid rgba(255,255,255,.1)', borderRadius: 16, padding: 24 }}>
            <span style={{ width: 48, height: 48, borderRadius: 12, background: 'linear-gradient(145deg,#38B0D6,#0E7490)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24 }}><Icon name="server" /></span>
            <div style={{ color: '#fff', fontWeight: 800, fontSize: 19, marginTop: 16 }}>平台管理後台</div>
            <div style={{ color: '#8FB6C2', fontSize: 14, marginTop: 6, lineHeight: 1.5 }}>Zoustec 客戶、流量與營收</div>
          </Link>
          <Link href="/portal" style={{ display: 'block', textDecoration: 'none', background: 'rgba(255,255,255,.04)', border: '1px solid rgba(255,255,255,.1)', borderRadius: 16, padding: 24 }}>
            <span style={{ width: 48, height: 48, borderRadius: 12, background: 'linear-gradient(145deg,#38B0D6,#0E7490)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24 }}><Icon name="compass" /></span>
            <div style={{ color: '#fff', fontWeight: 800, fontSize: 19, marginTop: 16 }}>活動入口網站</div>
            <div style={{ color: '#8FB6C2', fontSize: 14, marginTop: 6, lineHeight: 1.5 }}>對外公開的活動探索入口</div>
          </Link>
      </div>
    </main>
  );
}
