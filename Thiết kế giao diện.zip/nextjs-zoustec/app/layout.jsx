import './globals.css';
import Link from 'next/link';

export const metadata = {
  title: 'Zoustec AR 體驗平台',
  description: 'AR 集章互動體驗平台 — 6 個核心畫面',
};

const NAV = [
  ['/', '首頁'],
  ['/dashboard', '客戶後台'],
  ['/builder', '網站產生器'],
  ['/ar-studio', 'AI 3D'],
  ['/experience', 'WebAR 體驗'],
  ['/console', '平台後台'],
  ['/portal', '入口網站'],
];

export default function RootLayout({ children }) {
  return (
    <html lang="zh-Hant">
      <body>
        <nav style={{ position: 'sticky', top: 0, zIndex: 50, display: 'flex', alignItems: 'center', gap: 6, flexWrap: 'wrap', padding: '12px 20px', background: 'rgba(11,41,53,.85)', backdropFilter: 'blur(10px)', borderBottom: '1px solid rgba(255,255,255,.08)' }}>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 9, marginRight: 10, color: '#fff', fontWeight: 800, fontSize: 15 }}>
            <span style={{ width: 26, height: 26, borderRadius: 7, background: 'linear-gradient(145deg,#38B0D6,#0E7490)', display: 'inline-flex' }} />
            Zoustec AR
          </span>
          {NAV.map(([href, label]) => (
            <Link key={href} href={href} style={{ padding: '7px 13px', borderRadius: 9999, color: '#B6D4DE', fontSize: 13, fontWeight: 600, textDecoration: 'none', background: 'rgba(255,255,255,.06)' }}>
              {label}
            </Link>
          ))}
        </nav>
        {children}
      </body>
    </html>
  );
}
