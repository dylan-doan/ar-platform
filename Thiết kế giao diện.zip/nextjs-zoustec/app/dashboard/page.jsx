import { Icon } from '../../components/Icon';

export const metadata = { title: '客戶管理後台 · Zoustec AR' };

export default function Page() {
  return (
<section id="s1" data-screen-label="01 Bảng quản trị khách hàng" style={{maxWidth:'1620px', margin:'0 auto', padding:'40px 48px 24px'}}>
  <div style={{display:'flex', alignItems:'baseline', gap:'16px', marginBottom:'6px'}}>
    <span style={{fontSize:'13px', fontWeight:'800', letterSpacing:'.14em', color:'#6FCDE8'}}>01</span>
    <h2 style={{margin:'0', fontSize:'30px', fontWeight:'800', letterSpacing:'-0.02em', color:'#fff'}}>Bảng quản trị khách hàng</h2>
  </div>
  <p style={{margin:'0 0 28px', color:'#8FB6C2', fontSize:'15px', maxWidth:'70ch'}}>Cơ quan / doanh nghiệp quản lý sự kiện, cấu hình nhiệm vụ và theo dõi thống kê thời gian thực của riêng họ.</p>

  <div style={{display:'flex', gap:'40px', alignItems:'flex-start', flexWrap:'wrap'}}>

    
    <div style={{width:'1280px', borderRadius:'16px', overflow:'hidden', boxShadow:'var(--shadow-xl)', border:'1px solid rgba(0,0,0,.2)', background:'#fff', flex:'0 0 auto'}}>
      <div style={{height:'40px', background:'#0B2935', display:'flex', alignItems:'center', gap:'8px', padding:'0 16px'}}>
        <span style={{width:'11px', height:'11px', borderRadius:'50%', background:'#FF5F57'}}></span>
        <span style={{width:'11px', height:'11px', borderRadius:'50%', background:'#FEBC2E'}}></span>
        <span style={{width:'11px', height:'11px', borderRadius:'50%', background:'#28C840'}}></span>
        <div style={{marginLeft:'14px', flex:'1', maxWidth:'420px', height:'24px', borderRadius:'9999px', background:'rgba(255,255,255,.1)', display:'flex', alignItems:'center', padding:'0 12px', gap:'8px', color:'#8FB6C2', fontSize:'12px'}}><span style={{fontSize:'12px', display:'inline-flex', lineHeight:'0'}}><Icon name="lock" /></span>manage.zoustec.tw/dashboard</div>
      </div>
      <div style={{display:'flex', height:'820px', background:'var(--surface-app)'}}>

        
        <aside style={{width:'248px', flex:'0 0 auto', background:'var(--sidebar-bg)', display:'flex', flexDirection:'column', padding:'20px 14px'}}>
          <div style={{display:'flex', alignItems:'center', gap:'11px', padding:'4px 8px 22px'}}>
            <div style={{width:'38px', height:'38px', borderRadius:'10px', background:'linear-gradient(145deg,var(--primary-500),var(--primary-700))', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontSize:'20px', boxShadow:'0 4px 10px rgba(0,0,0,.3)'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="scan-line" /></span></div>
            <div><div style={{color:'#fff', fontWeight:'800', fontSize:'15px', letterSpacing:'-.01em', whiteSpace:'nowrap'}}>Zoustec AR</div><div style={{color:'#6FCDE8', fontSize:'11px', fontWeight:'600'}}>管理後台</div></div>
          </div>
          <div style={{fontSize:'10px', fontWeight:'700', letterSpacing:'.12em', color:'#4E7A88', padding:'8px 10px 6px'}}>活動</div>
          <a style={{display:'flex', alignItems:'center', gap:'12px', padding:'10px 12px', borderRadius:'8px', background:'var(--sidebar-active-bg)', color:'#fff', fontSize:'14px', fontWeight:'600', textDecoration:'none'}}><span style={{fontSize:'19px', display:'inline-flex', lineHeight:'0'}}><Icon name="layout-dashboard" /></span>總覽</a>
          <a style={{display:'flex', alignItems:'center', gap:'12px', padding:'10px 12px', borderRadius:'8px', color:'#B6D4DE', fontSize:'14px', fontWeight:'500', textDecoration:'none'}}><span style={{fontSize:'19px', display:'inline-flex', lineHeight:'0'}}><Icon name="calendar-check" /></span>活動</a>
          <a style={{display:'flex', alignItems:'center', gap:'12px', padding:'10px 12px', borderRadius:'8px', color:'#B6D4DE', fontSize:'14px', fontWeight:'500', textDecoration:'none'}}><span style={{fontSize:'19px', display:'inline-flex', lineHeight:'0'}}><Icon name="list-checks" /></span>任務與集章</a>
          <a style={{display:'flex', alignItems:'center', gap:'12px', padding:'10px 12px', borderRadius:'8px', color:'#B6D4DE', fontSize:'14px', fontWeight:'500', textDecoration:'none'}}><span style={{fontSize:'19px', display:'inline-flex', lineHeight:'0'}}><Icon name="box" /></span>AR / 3D 體驗</a>
          <a style={{display:'flex', alignItems:'center', gap:'12px', padding:'10px 12px', borderRadius:'8px', color:'#B6D4DE', fontSize:'14px', fontWeight:'500', textDecoration:'none'}}><span style={{fontSize:'19px', display:'inline-flex', lineHeight:'0'}}><Icon name="users" /></span>參與者</a>
          <a style={{display:'flex', alignItems:'center', gap:'12px', padding:'10px 12px', borderRadius:'8px', color:'#B6D4DE', fontSize:'14px', fontWeight:'500', textDecoration:'none'}}><span style={{fontSize:'19px', display:'inline-flex', lineHeight:'0'}}><Icon name="chart-no-axes-column" /></span>報表</a>
          <div style={{fontSize:'10px', fontWeight:'700', letterSpacing:'.12em', color:'#4E7A88', padding:'18px 10px 6px'}}>設定</div>
          <a style={{display:'flex', alignItems:'center', gap:'12px', padding:'10px 12px', borderRadius:'8px', color:'#B6D4DE', fontSize:'14px', fontWeight:'500', textDecoration:'none'}}><span style={{fontSize:'19px', display:'inline-flex', lineHeight:'0'}}><Icon name="palette" /></span>品牌與網域</a>
          <a style={{display:'flex', alignItems:'center', gap:'12px', padding:'10px 12px', borderRadius:'8px', color:'#B6D4DE', fontSize:'14px', fontWeight:'500', textDecoration:'none'}}><span style={{fontSize:'19px', display:'inline-flex', lineHeight:'0'}}><Icon name="settings" /></span>設定</a>
          <div style={{marginTop:'auto', display:'flex', alignItems:'center', gap:'11px', padding:'10px', borderTop:'1px solid rgba(255,255,255,.08)'}}>
            <div style={{width:'34px', height:'34px', borderRadius:'9999px', background:'var(--primary-500)', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:'700', fontSize:'13px'}}>TT</div>
            <div style={{flex:'1', minWidth:'0'}}><div style={{color:'#fff', fontSize:'13px', fontWeight:'600', whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis'}}>台南市觀光旅遊局</div><div style={{color:'#6FCDE8', fontSize:'11px'}}>管理員</div></div>
            <span style={{fontSize:'17px', color:'#8FB6C2', display:'inline-flex', lineHeight:'0'}}><Icon name="log-out" /></span>
          </div>
        </aside>

        
        <div style={{flex:'1', minWidth:'0', display:'flex', flexDirection:'column'}}>
          <header style={{height:'66px', flex:'0 0 auto', background:'#fff', borderBottom:'1px solid var(--border-subtle)', display:'flex', alignItems:'center', padding:'0 26px', gap:'16px'}}>
            <div><div style={{fontSize:'19px', fontWeight:'800', color:'var(--text-strong)', letterSpacing:'-.01em'}}>總覽</div></div>
            <div style={{marginLeft:'auto', display:'flex', alignItems:'center', gap:'12px'}}>
              <div style={{display:'flex', alignItems:'center', gap:'9px', height:'38px', padding:'0 14px', borderRadius:'8px', border:'1px solid var(--border-default)', background:'#fff', fontSize:'13px', fontWeight:'600', color:'var(--text-body)'}}><span style={{width:'8px', height:'8px', borderRadius:'50%', background:'var(--success-500)'}}></span>台南府城古蹟巡禮 2025<span style={{fontSize:'15px', color:'var(--text-muted)', display:'inline-flex', lineHeight:'0'}}><Icon name="chevron-down" /></span></div>
              <div style={{width:'38px', height:'38px', borderRadius:'8px', border:'1px solid var(--border-subtle)', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--text-muted)', fontSize:'18px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="search" /></span></div>
              <div style={{width:'38px', height:'38px', borderRadius:'8px', border:'1px solid var(--border-subtle)', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--text-muted)', fontSize:'18px', position:'relative'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="bell" /></span><span style={{position:'absolute', top:'8px', right:'9px', width:'7px', height:'7px', borderRadius:'50%', background:'var(--danger-500)', border:'1.5px solid #fff'}}></span></div>
            </div>
          </header>

          <div style={{flex:'1', overflow:'auto', padding:'24px 26px'}}>
            
            <div style={{display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:'16px', marginBottom:'16px'}}>
              <div style={{background:'#fff', border:'1px solid var(--border-subtle)', borderRadius:'12px', boxShadow:'var(--shadow-sm)', padding:'18px'}}>
                <div style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}><span style={{fontSize:'12px', fontWeight:'600', color:'var(--text-muted)'}}>參與人次</span><span style={{width:'32px', height:'32px', borderRadius:'8px', background:'var(--primary-50)', color:'var(--primary-600)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'16px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="users" /></span></span></div>
                <div style={{fontSize:'30px', fontWeight:'800', color:'var(--text-strong)', letterSpacing:'-.02em', marginTop:'12px', fontVariantNumeric:'tabular-nums'}}>12,847</div>
                <div style={{display:'flex', alignItems:'center', gap:'5px', marginTop:'6px', fontSize:'12px', fontWeight:'700', color:'var(--success-600)'}}><span style={{fontSize:'13px', display:'inline-flex', lineHeight:'0'}}><Icon name="trending-up" /></span>+18.2% <span style={{color:'var(--text-subtle)', fontWeight:'500'}}>較上週</span></div>
              </div>
              <div style={{background:'#fff', border:'1px solid var(--border-subtle)', borderRadius:'12px', boxShadow:'var(--shadow-sm)', padding:'18px'}}>
                <div style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}><span style={{fontSize:'12px', fontWeight:'600', color:'var(--text-muted)'}}>完成任務數</span><span style={{width:'32px', height:'32px', borderRadius:'8px', background:'var(--primary-50)', color:'var(--primary-600)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'16px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="list-checks" /></span></span></div>
                <div style={{fontSize:'30px', fontWeight:'800', color:'var(--text-strong)', letterSpacing:'-.02em', marginTop:'12px', fontVariantNumeric:'tabular-nums'}}>38,902</div>
                <div style={{display:'flex', alignItems:'center', gap:'5px', marginTop:'6px', fontSize:'12px', fontWeight:'700', color:'var(--success-600)'}}><span style={{fontSize:'13px', display:'inline-flex', lineHeight:'0'}}><Icon name="trending-up" /></span>+12.4% <span style={{color:'var(--text-subtle)', fontWeight:'500'}}>較上週</span></div>
              </div>
              <div style={{background:'#fff', border:'1px solid var(--border-subtle)', borderRadius:'12px', boxShadow:'var(--shadow-sm)', padding:'18px'}}>
                <div style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}><span style={{fontSize:'12px', fontWeight:'600', color:'var(--text-muted)'}}>已發放印章</span><span style={{width:'32px', height:'32px', borderRadius:'8px', background:'var(--primary-50)', color:'var(--primary-600)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'16px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="award" /></span></span></div>
                <div style={{fontSize:'30px', fontWeight:'800', color:'var(--text-strong)', letterSpacing:'-.02em', marginTop:'12px', fontVariantNumeric:'tabular-nums'}}>9,431</div>
                <div style={{display:'flex', alignItems:'center', gap:'5px', marginTop:'6px', fontSize:'12px', fontWeight:'700', color:'var(--success-600)'}}><span style={{fontSize:'13px', display:'inline-flex', lineHeight:'0'}}><Icon name="trending-up" /></span>+24.1% <span style={{color:'var(--text-subtle)', fontWeight:'500'}}>較上週</span></div>
              </div>
              <div style={{background:'#fff', border:'1px solid var(--border-subtle)', borderRadius:'12px', boxShadow:'var(--shadow-sm)', padding:'18px'}}>
                <div style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}><span style={{fontSize:'12px', fontWeight:'600', color:'var(--text-muted)'}}>完成率</span><span style={{width:'32px', height:'32px', borderRadius:'8px', background:'var(--primary-50)', color:'var(--primary-600)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'16px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="trophy" /></span></span></div>
                <div style={{fontSize:'30px', fontWeight:'800', color:'var(--text-strong)', letterSpacing:'-.02em', marginTop:'12px', fontVariantNumeric:'tabular-nums'}}>73.4%</div>
                <div style={{display:'flex', alignItems:'center', gap:'5px', marginTop:'6px', fontSize:'12px', fontWeight:'700', color:'var(--success-600)'}}><span style={{fontSize:'13px', display:'inline-flex', lineHeight:'0'}}><Icon name="trending-up" /></span>+5.2 分 <span style={{color:'var(--text-subtle)', fontWeight:'500'}}>較上週</span></div>
              </div>
            </div>

            
            <div style={{display:'grid', gridTemplateColumns:'1.9fr 1fr', gap:'16px', marginBottom:'16px'}}>
              <div style={{background:'#fff', border:'1px solid var(--border-subtle)', borderRadius:'12px', boxShadow:'var(--shadow-sm)', padding:'20px'}}>
                <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:'18px'}}>
                  <div><div style={{fontSize:'15px', fontWeight:'700', color:'var(--text-strong)'}}>每日參與人次</div><div style={{fontSize:'12px', color:'var(--text-muted)', marginTop:'2px'}}>最近 14 天</div></div>
                  <div style={{display:'flex', gap:'6px'}}>
                    <span style={{fontSize:'12px', fontWeight:'600', padding:'5px 11px', borderRadius:'9999px', background:'var(--primary-600)', color:'#fff'}}>14天</span>
                    <span style={{fontSize:'12px', fontWeight:'600', padding:'5px 11px', borderRadius:'9999px', color:'var(--text-muted)'}}>30天</span>
                    <span style={{fontSize:'12px', fontWeight:'600', padding:'5px 11px', borderRadius:'9999px', color:'var(--text-muted)'}}>季</span>
                  </div>
                </div>
                <svg viewBox="0 0 640 210" width="100%" height="210" preserveAspectRatio="none" style={{display:'block'}}>
                  <defs><linearGradient id="lg1" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#0E7490" stopOpacity="0.22"/><stop offset="1" stopColor="#0E7490" stopOpacity="0"/></linearGradient></defs>
                  <line x1="0" y1="40" x2="640" y2="40" stroke="#EEF2F6"/><line x1="0" y1="90" x2="640" y2="90" stroke="#EEF2F6"/><line x1="0" y1="140" x2="640" y2="140" stroke="#EEF2F6"/><line x1="0" y1="190" x2="640" y2="190" stroke="#E2E8F0"/>
                  <path d="M0,160 L49,150 L98,165 L147,120 L196,132 L245,98 L294,110 L343,72 L392,86 L441,58 L490,74 L539,44 L588,60 L640,34 L640,190 L0,190 Z" fill="url(#lg1)"/>
                  <polyline points="0,160 49,150 98,165 147,120 196,132 245,98 294,110 343,72 392,86 441,58 490,74 539,44 588,60 640,34" fill="none" stroke="#0E7490" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
                  <circle cx="640" cy="34" r="4.5" fill="#0E7490" stroke="#fff" strokeWidth="2"/>
                </svg>
              </div>
              <div style={{background:'#fff', border:'1px solid var(--border-subtle)', borderRadius:'12px', boxShadow:'var(--shadow-sm)', padding:'20px'}}>
                <div style={{fontSize:'15px', fontWeight:'700', color:'var(--text-strong)', marginBottom:'4px'}}>任務類型分布</div>
                <div style={{fontSize:'12px', color:'var(--text-muted)', marginBottom:'12px'}}>驗證方式分布</div>
                <div style={{display:'flex', alignItems:'center', gap:'18px'}}>
                  <svg viewBox="0 0 130 130" width="120" height="120" style={{flex:'0 0 auto'}}>
                    <g transform="rotate(-90 65 65)">
                      <circle cx="65" cy="65" r="54" fill="none" stroke="#EEF2F6" strokeWidth="18"/>
                      <circle cx="65" cy="65" r="54" fill="none" stroke="#0E7490" strokeWidth="18" strokeDasharray="156 183.3" strokeDashoffset="0"/>
                      <circle cx="65" cy="65" r="54" fill="none" stroke="#3B82F6" strokeWidth="18" strokeDasharray="115.4 223.9" strokeDashoffset="-156"/>
                      <circle cx="65" cy="65" r="54" fill="none" stroke="#6FCDE8" strokeWidth="18" strokeDasharray="67.9 271.4" strokeDashoffset="-271.4"/>
                    </g>
                    <text x="65" y="61" textAnchor="middle" fontSize="21" fontWeight="800" fill="#0F1B2D" fontFamily="var(--font-sans)">38.9K</text>
                    <text x="65" y="79" textAnchor="middle" fontSize="10" fontWeight="600" fill="#64748B">任務</text>
                  </svg>
                  <div style={{display:'flex', flexDirection:'column', gap:'10px', fontSize:'12.5px'}}>
                    <div style={{display:'flex', alignItems:'center', gap:'8px'}}><span style={{width:'10px', height:'10px', borderRadius:'3px', background:'#0E7490'}}></span><span style={{color:'var(--text-body)', fontWeight:'600'}}>QR + AR</span><span style={{marginLeft:'auto', color:'var(--text-muted)', fontWeight:'700'}}>46%</span></div>
                    <div style={{display:'flex', alignItems:'center', gap:'8px'}}><span style={{width:'10px', height:'10px', borderRadius:'3px', background:'#3B82F6'}}></span><span style={{color:'var(--text-body)', fontWeight:'600'}}>GPS + AR</span><span style={{marginLeft:'auto', color:'var(--text-muted)', fontWeight:'700'}}>34%</span></div>
                    <div style={{display:'flex', alignItems:'center', gap:'8px'}}><span style={{width:'10px', height:'10px', borderRadius:'3px', background:'#6FCDE8'}}></span><span style={{color:'var(--text-body)', fontWeight:'600'}}>混合</span><span style={{marginLeft:'auto', color:'var(--text-muted)', fontWeight:'700'}}>20%</span></div>
                  </div>
                </div>
              </div>
            </div>

            
            <div style={{background:'#fff', border:'1px solid var(--border-subtle)', borderRadius:'12px', boxShadow:'var(--shadow-sm)', overflow:'hidden'}}>
              <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', padding:'16px 20px', borderBottom:'1px solid var(--border-subtle)'}}>
                <div style={{fontSize:'15px', fontWeight:'700', color:'var(--text-strong)'}}>管理中的活動</div>
                <div style={{display:'flex', alignItems:'center', gap:'8px', height:'36px', padding:'0 14px', borderRadius:'8px', background:'var(--primary-600)', color:'#fff', fontSize:'13px', fontWeight:'600'}}><span style={{fontSize:'15px', display:'inline-flex', lineHeight:'0'}}><Icon name="plus" /></span>建立活動</div>
              </div>
              <table style={{width:'100%', borderCollapse:'collapse', fontSize:'13px'}}>
                <thead><tr style={{textAlign:'left', color:'var(--text-muted)', fontSize:'11px', letterSpacing:'.06em', textTransform:'uppercase'}}>
                  <th style={{padding:'11px 20px', fontWeight:'700'}}>活動</th><th style={{padding:'11px', fontWeight:'700'}}>類型</th><th style={{padding:'11px', fontWeight:'700'}}>任務</th><th style={{padding:'11px', fontWeight:'700', textAlign:'right'}}>參與人次</th><th style={{padding:'11px', fontWeight:'700'}}>狀態</th><th style={{padding:'11px 20px'}}></th>
                </tr></thead>
                <tbody style={{color:'var(--text-body)'}}>
                  <tr style={{borderTop:'1px solid var(--border-subtle)'}}><td style={{padding:'13px 20px'}}><div style={{fontWeight:'700', color:'var(--text-strong)'}}>台南府城古蹟巡禮 2025</div><div style={{color:'var(--text-subtle)', fontSize:'11.5px', fontFamily:'var(--font-mono)'}}>EVT-0231 · tainan-heritage.tw</div></td><td style={{padding:'13px'}}><span style={{display:'inline-flex', alignItems:'center', gap:'6px', padding:'4px 9px', borderRadius:'9999px', background:'var(--primary-50)', color:'var(--primary-700)', fontWeight:'600', fontSize:'11.5px'}}><span style={{fontSize:'12px', display:'inline-flex', lineHeight:'0'}}><Icon name="building-2" /></span>城市</span></td><td style={{padding:'13px', fontWeight:'600'}}>12</td><td style={{padding:'13px', textAlign:'right', fontWeight:'700', fontVariantNumeric:'tabular-nums'}}>8,204</td><td style={{padding:'13px'}}><span style={{display:'inline-flex', alignItems:'center', gap:'6px', padding:'4px 10px', borderRadius:'9999px', background:'var(--status-success-bg)', color:'var(--status-success-fg)', fontWeight:'700', fontSize:'11.5px'}}><span style={{width:'6px', height:'6px', borderRadius:'50%', background:'currentColor'}}></span>進行中</span></td><td style={{padding:'13px 20px', textAlign:'right', color:'var(--text-muted)', fontSize:'17px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="chevron-right" /></span></td></tr>
                  <tr style={{borderTop:'1px solid var(--border-subtle)'}}><td style={{padding:'13px 20px'}}><div style={{fontWeight:'700', color:'var(--text-strong)'}}>太魯閣山徑挑戰</div><div style={{color:'var(--text-subtle)', fontSize:'11.5px', fontFamily:'var(--font-mono)'}}>EVT-0244 · taroko.trek.tw</div></td><td style={{padding:'13px'}}><span style={{display:'inline-flex', alignItems:'center', gap:'6px', padding:'4px 9px', borderRadius:'9999px', background:'var(--primary-50)', color:'var(--primary-700)', fontWeight:'600', fontSize:'11.5px'}}><span style={{fontSize:'12px', display:'inline-flex', lineHeight:'0'}}><Icon name="mountain" /></span>登山</span></td><td style={{padding:'13px', fontWeight:'600'}}>8</td><td style={{padding:'13px', textAlign:'right', fontWeight:'700', fontVariantNumeric:'tabular-nums'}}>3,017</td><td style={{padding:'13px'}}><span style={{display:'inline-flex', alignItems:'center', gap:'6px', padding:'4px 10px', borderRadius:'9999px', background:'var(--status-success-bg)', color:'var(--status-success-fg)', fontWeight:'700', fontSize:'11.5px'}}><span style={{width:'6px', height:'6px', borderRadius:'50%', background:'currentColor'}}></span>進行中</span></td><td style={{padding:'13px 20px', textAlign:'right', color:'var(--text-muted)', fontSize:'17px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="chevron-right" /></span></td></tr>
                  <tr style={{borderTop:'1px solid var(--border-subtle)'}}><td style={{padding:'13px 20px'}}><div style={{fontWeight:'700', color:'var(--text-strong)'}}>夢時代新春集點會</div><div style={{color:'var(--text-subtle)', fontSize:'11.5px', fontFamily:'var(--font-mono)'}}>EVT-0258 · dreammall-cny.tw</div></td><td style={{padding:'13px'}}><span style={{display:'inline-flex', alignItems:'center', gap:'6px', padding:'4px 9px', borderRadius:'9999px', background:'var(--primary-50)', color:'var(--primary-700)', fontWeight:'600', fontSize:'11.5px'}}><span style={{fontSize:'12px', display:'inline-flex', lineHeight:'0'}}><Icon name="shopping-bag" /></span>購物</span></td><td style={{padding:'13px', fontWeight:'600'}}>15</td><td style={{padding:'13px', textAlign:'right', fontWeight:'700', fontVariantNumeric:'tabular-nums'}}>1,626</td><td style={{padding:'13px'}}><span style={{display:'inline-flex', alignItems:'center', gap:'6px', padding:'4px 10px', borderRadius:'9999px', background:'var(--status-warning-bg)', color:'var(--status-warning-fg)', fontWeight:'700', fontSize:'11.5px'}}><span style={{width:'6px', height:'6px', borderRadius:'50%', background:'currentColor'}}></span>即將開始</span></td><td style={{padding:'13px 20px', textAlign:'right', color:'var(--text-muted)', fontSize:'17px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="chevron-right" /></span></td></tr>
                  <tr style={{borderTop:'1px solid var(--border-subtle)'}}><td style={{padding:'13px 20px'}}><div style={{fontWeight:'700', color:'var(--text-strong)'}}>鹿港老街夜遊</div><div style={{color:'var(--text-subtle)', fontSize:'11.5px', fontFamily:'var(--font-mono)'}}>EVT-0261 · 草稿</div></td><td style={{padding:'13px'}}><span style={{display:'inline-flex', alignItems:'center', gap:'6px', padding:'4px 9px', borderRadius:'9999px', background:'var(--primary-50)', color:'var(--primary-700)', fontWeight:'600', fontSize:'11.5px'}}><span style={{fontSize:'12px', display:'inline-flex', lineHeight:'0'}}><Icon name="building-2" /></span>城市</span></td><td style={{padding:'13px', fontWeight:'600'}}>6</td><td style={{padding:'13px', textAlign:'right', fontWeight:'700', fontVariantNumeric:'tabular-nums'}}>—</td><td style={{padding:'13px'}}><span style={{display:'inline-flex', alignItems:'center', gap:'6px', padding:'4px 10px', borderRadius:'9999px', background:'var(--status-neutral-bg)', color:'var(--status-neutral-fg)', fontWeight:'700', fontSize:'11.5px'}}><span style={{width:'6px', height:'6px', borderRadius:'50%', background:'currentColor'}}></span>草稿</span></td><td style={{padding:'13px 20px', textAlign:'right', color:'var(--text-muted)', fontSize:'17px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="chevron-right" /></span></td></tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>

    
    <div style={{width:'340px', flex:'0 0 auto', background:'#0B2935', borderRadius:'44px', padding:'11px', boxShadow:'var(--shadow-xl)', border:'1px solid rgba(0,0,0,.3)'}}>
      <div style={{borderRadius:'34px', overflow:'hidden', background:'var(--surface-app)', position:'relative', height:'720px', display:'flex', flexDirection:'column'}}>
        <div style={{position:'absolute', top:'0', left:'0', right:'0', height:'34px', display:'flex', alignItems:'center', justifyContent:'space-between', padding:'10px 26px 0', fontSize:'12px', fontWeight:'700', color:'var(--text-strong)', zIndex:'5'}}><span>9:41</span><span style={{width:'110px', height:'26px', background:'#0B2935', borderRadius:'0 0 16px 16px', position:'absolute', left:'50%', transform:'translateX(-50%)', top:'0'}}></span><span style={{display:'flex', gap:'5px', fontSize:'13px'}}><Icon name="signal-high" /><Icon name="wifi" /><Icon name="battery-full" /></span></div>
        <div style={{height:'44px', flex:'0 0 auto', background:'#fff', borderBottom:'1px solid var(--border-subtle)', display:'flex', alignItems:'center', padding:'0 16px', gap:'10px', marginTop:'34px'}}>
          <div style={{width:'30px', height:'30px', borderRadius:'8px', background:'linear-gradient(145deg,var(--primary-500),var(--primary-700))', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontSize:'16px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="scan-line" /></span></div>
          <div style={{fontWeight:'800', fontSize:'14px', color:'var(--text-strong)'}}>總覽</div>
          <div style={{marginLeft:'auto', width:'32px', height:'32px', borderRadius:'8px', border:'1px solid var(--border-subtle)', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--text-muted)', fontSize:'16px', position:'relative'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="bell" /></span><span style={{position:'absolute', top:'6px', right:'7px', width:'6px', height:'6px', borderRadius:'50%', background:'var(--danger-500)', border:'1.5px solid #fff'}}></span></div>
        </div>
        <div style={{flex:'1', overflow:'auto', padding:'16px 14px 84px'}}>
          <div style={{display:'flex', alignItems:'center', gap:'8px', height:'38px', padding:'0 12px', borderRadius:'8px', border:'1px solid var(--border-default)', background:'#fff', fontSize:'13px', fontWeight:'600', color:'var(--text-body)', marginBottom:'14px'}}><span style={{width:'8px', height:'8px', borderRadius:'50%', background:'var(--success-500)'}}></span>台南府城古蹟巡禮 2025<span style={{marginLeft:'auto', fontSize:'15px', color:'var(--text-muted)', display:'inline-flex', lineHeight:'0'}}><Icon name="chevron-down" /></span></div>
          <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:'11px', marginBottom:'11px'}}>
            <div style={{background:'#fff', border:'1px solid var(--border-subtle)', borderRadius:'12px', boxShadow:'var(--shadow-sm)', padding:'14px'}}><div style={{fontSize:'11px', color:'var(--text-muted)', fontWeight:'600'}}>參與人次</div><div style={{fontSize:'23px', fontWeight:'800', color:'var(--text-strong)', marginTop:'6px'}}>8,204</div><div style={{fontSize:'11px', fontWeight:'700', color:'var(--success-600)', marginTop:'3px'}}>+18.2%</div></div>
            <div style={{background:'#fff', border:'1px solid var(--border-subtle)', borderRadius:'12px', boxShadow:'var(--shadow-sm)', padding:'14px'}}><div style={{fontSize:'11px', color:'var(--text-muted)', fontWeight:'600'}}>已發印章</div><div style={{fontSize:'23px', fontWeight:'800', color:'var(--text-strong)', marginTop:'6px'}}>6,190</div><div style={{fontSize:'11px', fontWeight:'700', color:'var(--success-600)', marginTop:'3px'}}>+24.1%</div></div>
            <div style={{background:'#fff', border:'1px solid var(--border-subtle)', borderRadius:'12px', boxShadow:'var(--shadow-sm)', padding:'14px'}}><div style={{fontSize:'11px', color:'var(--text-muted)', fontWeight:'600'}}>完成率</div><div style={{fontSize:'23px', fontWeight:'800', color:'var(--text-strong)', marginTop:'6px'}}>73.4%</div><div style={{fontSize:'11px', fontWeight:'700', color:'var(--success-600)', marginTop:'3px'}}>+5.2分</div></div>
            <div style={{background:'#fff', border:'1px solid var(--border-subtle)', borderRadius:'12px', boxShadow:'var(--shadow-sm)', padding:'14px'}}><div style={{fontSize:'11px', color:'var(--text-muted)', fontWeight:'600'}}>任務</div><div style={{fontSize:'23px', fontWeight:'800', color:'var(--text-strong)', marginTop:'6px'}}>12</div><div style={{fontSize:'11px', fontWeight:'600', color:'var(--text-subtle)', marginTop:'3px'}}>啟用中</div></div>
          </div>
          <div style={{background:'#fff', border:'1px solid var(--border-subtle)', borderRadius:'12px', boxShadow:'var(--shadow-sm)', padding:'16px', marginBottom:'11px'}}>
            <div style={{fontSize:'13px', fontWeight:'700', color:'var(--text-strong)', marginBottom:'12px'}}>14 天參與人次</div>
            <svg viewBox="0 0 300 90" width="100%" height="90" preserveAspectRatio="none"><defs><linearGradient id="lgm" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#0E7490" stopOpacity="0.2"/><stop offset="1" stopColor="#0E7490" stopOpacity="0"/></linearGradient></defs><path d="M0,70 L40,64 L80,72 L120,50 L160,56 L200,38 L240,44 L280,24 L300,18 L300,90 L0,90 Z" fill="url(#lgm)"/><polyline points="0,70 40,64 80,72 120,50 160,56 200,38 240,44 280,24 300,18" fill="none" stroke="#0E7490" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/></svg>
          </div>
          <div style={{fontSize:'12px', fontWeight:'700', color:'var(--text-muted)', letterSpacing:'.04em', textTransform:'uppercase', margin:'6px 4px 10px'}}>熱門任務</div>
          <div style={{background:'#fff', border:'1px solid var(--border-subtle)', borderRadius:'12px', boxShadow:'var(--shadow-sm)', padding:'13px', display:'flex', alignItems:'center', gap:'12px', marginBottom:'9px'}}><span style={{width:'36px', height:'36px', borderRadius:'9px', background:'var(--primary-50)', color:'var(--primary-600)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'18px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="qr-code" /></span></span><div style={{flex:'1', minWidth:'0'}}><div style={{fontWeight:'700', fontSize:'13px', color:'var(--text-strong)'}}>安平古堡</div><div style={{fontSize:'11px', color:'var(--text-muted)'}}>QR + AR · 2,104 次</div></div><span style={{fontSize:'11px', fontWeight:'700', color:'var(--primary-600)'}}>86%</span></div>
          <div style={{background:'#fff', border:'1px solid var(--border-subtle)', borderRadius:'12px', boxShadow:'var(--shadow-sm)', padding:'13px', display:'flex', alignItems:'center', gap:'12px'}}><span style={{width:'36px', height:'36px', borderRadius:'9px', background:'var(--primary-50)', color:'var(--primary-600)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'18px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="map-pin" /></span></span><div style={{flex:'1', minWidth:'0'}}><div style={{fontWeight:'700', fontSize:'13px', color:'var(--text-strong)'}}>孔子廟</div><div style={{fontSize:'11px', color:'var(--text-muted)'}}>GPS + AR · 1,870 次</div></div><span style={{fontSize:'11px', fontWeight:'700', color:'var(--primary-600)'}}>78%</span></div>
        </div>
        <div style={{position:'absolute', bottom:'0', left:'0', right:'0', height:'66px', background:'#fff', borderTop:'1px solid var(--border-subtle)', display:'flex', alignItems:'center', justifyContent:'space-around', padding:'0 8px 8px'}}>
          <div style={{display:'flex', flexDirection:'column', alignItems:'center', gap:'3px', color:'var(--primary-600)', fontSize:'10px', fontWeight:'700'}}><span style={{fontSize:'21px', display:'inline-flex', lineHeight:'0'}}><Icon name="layout-dashboard" /></span>總覽</div>
          <div style={{display:'flex', flexDirection:'column', alignItems:'center', gap:'3px', color:'var(--text-muted)', fontSize:'10px', fontWeight:'600'}}><span style={{fontSize:'21px', display:'inline-flex', lineHeight:'0'}}><Icon name="calendar-check" /></span>活動</div>
          <div style={{display:'flex', flexDirection:'column', alignItems:'center', gap:'3px', color:'var(--text-muted)', fontSize:'10px', fontWeight:'600'}}><span style={{fontSize:'21px', display:'inline-flex', lineHeight:'0'}}><Icon name="list-checks" /></span>任務</div>
          <div style={{display:'flex', flexDirection:'column', alignItems:'center', gap:'3px', color:'var(--text-muted)', fontSize:'10px', fontWeight:'600'}}><span style={{fontSize:'21px', display:'inline-flex', lineHeight:'0'}}><Icon name="chart-no-axes-column" /></span>報表</div>
        </div>
      </div>
    </div>
  </div>
</section>
  );
}
