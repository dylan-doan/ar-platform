import { Icon } from '../../components/Icon';

export const metadata = { title: '活動網站產生器 · Zoustec AR' };

export default function Page() {
  return (
<section id="s2" data-screen-label="02 Trình tạo website sự kiện" style={{maxWidth:'1620px', margin:'0 auto', padding:'40px 48px 24px'}}>
  <div style={{display:'flex', alignItems:'baseline', gap:'16px', marginBottom:'6px'}}>
    <span style={{fontSize:'13px', fontWeight:'800', letterSpacing:'.14em', color:'#6FCDE8'}}>02</span>
    <h2 style={{margin:'0', fontSize:'30px', fontWeight:'800', letterSpacing:'-0.02em', color:'#fff'}}>Trình tạo website sự kiện</h2>
  </div>
  <p style={{margin:'0 0 28px', color:'#8FB6C2', fontSize:'15px', maxWidth:'70ch'}}>Chọn template theo loại sự kiện, tùy chỉnh nội dung kéo–thả, xem trước trực tiếp và xuất template frontend làm deliverable.</p>

  <div style={{display:'flex', gap:'40px', alignItems:'flex-start', flexWrap:'wrap'}}>

    
    <div style={{display:'flex', flexDirection:'column', gap:'14px', flex:'0 0 auto'}}>
      <div style={{width:'1280px', borderRadius:'16px', overflow:'hidden', boxShadow:'var(--shadow-xl)', border:'1px solid rgba(0,0,0,.2)', background:'#fff'}}>
        <div style={{height:'40px', background:'#0B2935', display:'flex', alignItems:'center', gap:'8px', padding:'0 16px'}}>
          <span style={{width:'11px', height:'11px', borderRadius:'50%', background:'#FF5F57'}}></span><span style={{width:'11px', height:'11px', borderRadius:'50%', background:'#FEBC2E'}}></span><span style={{width:'11px', height:'11px', borderRadius:'50%', background:'#28C840'}}></span>
          <div style={{marginLeft:'14px', flex:'1', maxWidth:'420px', height:'24px', borderRadius:'9999px', background:'rgba(255,255,255,.1)', display:'flex', alignItems:'center', padding:'0 12px', gap:'8px', color:'#8FB6C2', fontSize:'12px'}}><span style={{fontSize:'12px', display:'inline-flex', lineHeight:'0'}}><Icon name="lock" /></span>manage.zoustec.tw/events/new</div>
        </div>
        <div style={{height:'56px', background:'#fff', borderBottom:'1px solid var(--border-subtle)', display:'flex', alignItems:'center', padding:'0 22px', gap:'11px'}}>
          <span style={{width:'20px', height:'20px', borderRadius:'9999px', background:'var(--primary-600)', color:'#fff', display:'inline-flex', alignItems:'center', justifyContent:'center', fontSize:'11px', fontWeight:'700'}}>1</span>
          <div style={{fontSize:'15px', fontWeight:'800', color:'var(--text-strong)'}}>建立新活動</div>
          <div style={{marginLeft:'auto', width:'34px', height:'34px', borderRadius:'8px', border:'1px solid var(--border-subtle)', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--text-muted)', fontSize:'17px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="x" /></span></div>
        </div>

        <div style={{background:'var(--surface-app)', padding:'44px 40px 40px', minHeight:'764px'}}>
          <div style={{maxWidth:'820px', margin:'0 auto'}}>
            <div style={{fontSize:'11px', fontWeight:'700', letterSpacing:'.12em', textTransform:'uppercase', color:'var(--primary-600)', textAlign:'center'}}>步驟 1 · 建立</div>
            <h3 style={{margin:'10px 0 0', textAlign:'center', fontSize:'30px', fontWeight:'800', letterSpacing:'-.02em', color:'var(--text-strong)'}}>您想舉辦什麼活動？</h3>
            <p style={{margin:'12px auto 0', textAlign:'center', maxWidth:'60ch', fontSize:'15px', color:'var(--text-muted)', lineHeight:'1.6'}}>用文字描述，或選擇類型 — 系統會依活動類型自動生成網站架構、內容區塊與任務建議。</p>

            
            <div style={{marginTop:'28px', background:'#fff', border:'1.5px solid var(--primary-200)', borderRadius:'16px', boxShadow:'var(--shadow-md)', overflow:'hidden'}}>
              <div style={{display:'flex', alignItems:'center', gap:'10px', padding:'14px 18px', borderBottom:'1px solid var(--border-subtle)'}}>
                <span style={{width:'30px', height:'30px', borderRadius:'8px', background:'linear-gradient(145deg,#6FCDE8,#0E7490)', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'16px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="sparkles" /></span></span>
                <span style={{fontSize:'14px', fontWeight:'800', color:'var(--text-strong)'}}>AI 快速生成</span>
                <span style={{fontSize:'10.5px', fontWeight:'700', letterSpacing:'.06em', color:'var(--info-700)', background:'var(--status-info-bg)', padding:'3px 8px', borderRadius:'9999px'}}>BETA</span>
                <span style={{marginLeft:'auto', fontSize:'12px', color:'var(--text-subtle)'}}>自動辨識活動類型</span>
              </div>
              <div style={{padding:'16px 18px 8px', fontSize:'15px', color:'var(--text-strong)', lineHeight:'1.6', minHeight:'64px'}}>台南府城古蹟一日遊，約 12 個古蹟停靠點，於御龜碑掃描 AR 並收集紀念印章。<span style={{display:'inline-block', width:'2px', height:'18px', background:'var(--primary-600)', verticalAlign:'-3px', marginLeft:'2px'}}></span></div>
              <div style={{display:'flex', alignItems:'center', gap:'10px', padding:'8px 16px 16px'}}>
                <div style={{display:'flex', gap:'7px', flexWrap:'wrap'}}>
                  <span style={{display:'inline-flex', alignItems:'center', gap:'6px', padding:'6px 11px', borderRadius:'9999px', background:'var(--surface-sunken)', color:'var(--text-body)', fontSize:'12px', fontWeight:'600'}}><span style={{fontSize:'13px', color:'var(--warning-600)', display:'inline-flex', lineHeight:'0'}}><Icon name="lightbulb" /></span>街頭慶典</span>
                  <span style={{display:'inline-flex', alignItems:'center', gap:'6px', padding:'6px 11px', borderRadius:'9999px', background:'var(--surface-sunken)', color:'var(--text-body)', fontSize:'12px', fontWeight:'600'}}>登山路線</span>
                  <span style={{display:'inline-flex', alignItems:'center', gap:'6px', padding:'6px 11px', borderRadius:'9999px', background:'var(--surface-sunken)', color:'var(--text-body)', fontSize:'12px', fontWeight:'600'}}>商場集點</span>
                </div>
                <div style={{marginLeft:'auto', display:'inline-flex', alignItems:'center', gap:'8px', height:'42px', padding:'0 20px', borderRadius:'9999px', background:'var(--primary-600)', color:'#fff', fontSize:'14px', fontWeight:'700', boxShadow:'var(--shadow-sm)'}}><span style={{fontSize:'16px', display:'inline-flex', lineHeight:'0'}}><Icon name="wand-2" /></span>用 AI 生成</div>
              </div>
            </div>

            <div style={{display:'flex', alignItems:'center', gap:'16px', margin:'26px 0 18px'}}><span style={{flex:'1', height:'1px', background:'var(--border-subtle)'}}></span><span style={{fontSize:'12px', fontWeight:'700', color:'var(--text-subtle)', letterSpacing:'.04em'}}>或選擇活動類型</span><span style={{flex:'1', height:'1px', background:'var(--border-subtle)'}}></span></div>

            <div style={{display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'16px'}}>
              
              <div style={{background:'#fff', border:'1.5px solid var(--primary-600)', borderRadius:'14px', padding:'18px', boxShadow:'0 0 0 3px var(--primary-50)'}}>
                <div style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}><span style={{width:'44px', height:'44px', borderRadius:'11px', background:'var(--primary-600)', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'21px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="building-2" /></span></span><span style={{color:'var(--primary-600)', fontSize:'20px', display:'inline-flex', lineHeight:'0'}}><Icon name="circle-check" /></span></div>
                <div style={{fontSize:'16px', fontWeight:'800', color:'var(--text-strong)', marginTop:'14px'}}>城市探索</div>
                <div style={{fontSize:'12.5px', color:'var(--text-muted)', marginTop:'3px', lineHeight:'1.5'}}>Urban exploration · 景點與文化</div>
                <div style={{marginTop:'14px', display:'flex', flexDirection:'column', gap:'8px'}}>
                  <div style={{display:'flex', alignItems:'center', gap:'8px', fontSize:'12.5px', color:'var(--text-body)'}}><span style={{fontSize:'14px', color:'var(--success-600)', display:'inline-flex', lineHeight:'0'}}><Icon name="check" /></span>景點地圖</div>
                  <div style={{display:'flex', alignItems:'center', gap:'8px', fontSize:'12.5px', color:'var(--text-body)'}}><span style={{fontSize:'14px', color:'var(--success-600)', display:'inline-flex', lineHeight:'0'}}><Icon name="check" /></span>各點文化內容</div>
                  <div style={{display:'flex', alignItems:'center', gap:'8px', fontSize:'12.5px', color:'var(--text-body)'}}><span style={{fontSize:'14px', color:'var(--success-600)', display:'inline-flex', lineHeight:'0'}}><Icon name="check" /></span>古蹟 QR + AR 任務</div>
                </div>
              </div>
              
              <div style={{background:'#fff', border:'1px solid var(--border-subtle)', borderRadius:'14px', padding:'18px'}}>
                <div style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}><span style={{width:'44px', height:'44px', borderRadius:'11px', background:'var(--primary-50)', color:'var(--primary-600)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'21px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="mountain" /></span></span><span style={{width:'20px', height:'20px', borderRadius:'9999px', border:'1.5px solid var(--border-default)'}}></span></div>
                <div style={{fontSize:'16px', fontWeight:'800', color:'var(--text-strong)', marginTop:'14px'}}>登山步道</div>
                <div style={{fontSize:'12.5px', color:'var(--text-muted)', marginTop:'3px', lineHeight:'1.5'}}>Outdoor · 戶外路線</div>
                <div style={{marginTop:'14px', display:'flex', flexDirection:'column', gap:'8px'}}>
                  <div style={{display:'flex', alignItems:'center', gap:'8px', fontSize:'12.5px', color:'var(--text-body)'}}><span style={{fontSize:'14px', color:'var(--text-muted)', display:'inline-flex', lineHeight:'0'}}><Icon name="check" /></span>安全提醒</div>
                  <div style={{display:'flex', alignItems:'center', gap:'8px', fontSize:'12.5px', color:'var(--text-body)'}}><span style={{fontSize:'14px', color:'var(--text-muted)', display:'inline-flex', lineHeight:'0'}}><Icon name="check" /></span>路線與難度資訊</div>
                  <div style={{display:'flex', alignItems:'center', gap:'8px', fontSize:'12.5px', color:'var(--text-body)'}}><span style={{fontSize:'14px', color:'var(--text-muted)', display:'inline-flex', lineHeight:'0'}}><Icon name="check" /></span>GPS 檢查點</div>
                </div>
              </div>
              
              <div style={{background:'#fff', border:'1px solid var(--border-subtle)', borderRadius:'14px', padding:'18px'}}>
                <div style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}><span style={{width:'44px', height:'44px', borderRadius:'11px', background:'var(--primary-50)', color:'var(--primary-600)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'21px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="shopping-bag" /></span></span><span style={{width:'20px', height:'20px', borderRadius:'9999px', border:'1.5px solid var(--border-default)'}}></span></div>
                <div style={{fontSize:'16px', fontWeight:'800', color:'var(--text-strong)', marginTop:'14px'}}>購物中心 / 展館</div>
                <div style={{fontSize:'12.5px', color:'var(--text-muted)', marginTop:'3px', lineHeight:'1.5'}}>Indoor · 商場、展場</div>
                <div style={{marginTop:'14px', display:'flex', flexDirection:'column', gap:'8px'}}>
                  <div style={{display:'flex', alignItems:'center', gap:'8px', fontSize:'12.5px', color:'var(--text-body)'}}><span style={{fontSize:'14px', color:'var(--text-muted)', display:'inline-flex', lineHeight:'0'}}><Icon name="check" /></span>店家位置圖</div>
                  <div style={{display:'flex', alignItems:'center', gap:'8px', fontSize:'12.5px', color:'var(--text-body)'}}><span style={{fontSize:'14px', color:'var(--text-muted)', display:'inline-flex', lineHeight:'0'}}><Icon name="check" /></span>消費任務</div>
                  <div style={{display:'flex', alignItems:'center', gap:'8px', fontSize:'12.5px', color:'var(--text-body)'}}><span style={{fontSize:'14px', color:'var(--text-muted)', display:'inline-flex', lineHeight:'0'}}><Icon name="check" /></span>室內 QR 任務</div>
                </div>
              </div>
            </div>

            <div style={{display:'flex', alignItems:'center', gap:'12px', marginTop:'22px'}}>
              <div style={{display:'flex', alignItems:'center', gap:'9px', flex:'1', padding:'12px 15px', borderRadius:'11px', background:'var(--surface-brand-subtle)', border:'1px solid var(--primary-200)', fontSize:'12.5px', color:'var(--primary-800)', lineHeight:'1.5'}}><span style={{fontSize:'16px', color:'var(--primary-600)', display:'inline-flex', lineHeight:'0'}}><Icon name="info" /></span>網站架構與內容區塊會依類型自動生成 — 您可在步驟 2 進一步調整。</div>
              <div style={{display:'inline-flex', alignItems:'center', gap:'8px', height:'46px', padding:'0 22px', borderRadius:'9999px', background:'var(--primary-600)', color:'#fff', fontSize:'14px', fontWeight:'700', boxShadow:'var(--shadow-sm)'}}>生成並編輯<span style={{fontSize:'16px', display:'inline-flex', lineHeight:'0'}}><Icon name="arrow-right" /></span></div>
            </div>
          </div>
        </div>
      </div>
      <div style={{display:'flex', alignItems:'center', gap:'8px', color:'#8FB6C2', fontSize:'12.5px', fontWeight:'600', paddingLeft:'4px'}}><span style={{width:'18px', height:'18px', borderRadius:'9999px', background:'rgba(255,255,255,.12)', color:'#6FCDE8', display:'inline-flex', alignItems:'center', justifyContent:'center', fontSize:'10px', fontWeight:'700'}}>1</span>Chọn loại &amp; tự sinh kiến trúc — có trợ lý AI</div>
    </div>

    <div style={{display:'flex', flexDirection:'column', gap:'14px', flex:'0 0 auto'}}>
    
    <div style={{width:'1280px', borderRadius:'16px', overflow:'hidden', boxShadow:'var(--shadow-xl)', border:'1px solid rgba(0,0,0,.2)', background:'#fff', flex:'0 0 auto'}}>
      <div style={{height:'40px', background:'#0B2935', display:'flex', alignItems:'center', gap:'8px', padding:'0 16px'}}>
        <span style={{width:'11px', height:'11px', borderRadius:'50%', background:'#FF5F57'}}></span><span style={{width:'11px', height:'11px', borderRadius:'50%', background:'#FEBC2E'}}></span><span style={{width:'11px', height:'11px', borderRadius:'50%', background:'#28C840'}}></span>
        <div style={{marginLeft:'14px', flex:'1', maxWidth:'440px', height:'24px', borderRadius:'9999px', background:'rgba(255,255,255,.1)', display:'flex', alignItems:'center', padding:'0 12px', gap:'8px', color:'#8FB6C2', fontSize:'12px'}}><span style={{fontSize:'12px', display:'inline-flex', lineHeight:'0'}}><Icon name="lock" /></span>manage.zoustec.tw/events/tainan-2025/builder</div>
      </div>
      
      <div style={{height:'60px', background:'#fff', borderBottom:'1px solid var(--border-subtle)', display:'flex', alignItems:'center', padding:'0 20px', gap:'18px'}}>
        <div style={{display:'flex', alignItems:'center', gap:'9px', fontSize:'14px', fontWeight:'700', color:'var(--text-strong)'}}><span style={{fontSize:'17px', color:'var(--primary-600)', display:'inline-flex', lineHeight:'0'}}><Icon name="layout-template" /></span>網站產生器</div>
        <div style={{display:'flex', alignItems:'center', gap:'6px', marginLeft:'8px'}}>
          <span style={{display:'inline-flex', alignItems:'center', gap:'7px', fontSize:'12.5px', fontWeight:'600', color:'var(--text-muted)'}}><span style={{width:'20px', height:'20px', borderRadius:'9999px', background:'var(--success-500)', color:'#fff', display:'inline-flex', alignItems:'center', justifyContent:'center', fontSize:'11px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="check" /></span></span>範本</span>
          <span style={{width:'22px', height:'1px', background:'var(--border-default)'}}></span>
          <span style={{display:'inline-flex', alignItems:'center', gap:'7px', fontSize:'12.5px', fontWeight:'700', color:'var(--primary-700)'}}><span style={{width:'20px', height:'20px', borderRadius:'9999px', background:'var(--primary-600)', color:'#fff', display:'inline-flex', alignItems:'center', justifyContent:'center', fontSize:'11px', fontWeight:'700'}}>2</span>內容</span>
          <span style={{width:'22px', height:'1px', background:'var(--border-default)'}}></span>
          <span style={{display:'inline-flex', alignItems:'center', gap:'7px', fontSize:'12.5px', fontWeight:'600', color:'var(--text-subtle)'}}><span style={{width:'20px', height:'20px', borderRadius:'9999px', background:'var(--neutral-200)', color:'var(--text-muted)', display:'inline-flex', alignItems:'center', justifyContent:'center', fontSize:'11px', fontWeight:'700'}}>3</span>品牌</span>
          <span style={{width:'22px', height:'1px', background:'var(--border-default)'}}></span>
          <span style={{display:'inline-flex', alignItems:'center', gap:'7px', fontSize:'12.5px', fontWeight:'600', color:'var(--text-subtle)'}}><span style={{width:'20px', height:'20px', borderRadius:'9999px', background:'var(--neutral-200)', color:'var(--text-muted)', display:'inline-flex', alignItems:'center', justifyContent:'center', fontSize:'11px', fontWeight:'700'}}>4</span>匯出</span>
        </div>
        <div style={{marginLeft:'auto', display:'flex', alignItems:'center', gap:'10px'}}>
          <div style={{display:'flex', padding:'3px', borderRadius:'9px', background:'var(--surface-sunken)', gap:'2px'}}><span style={{width:'32px', height:'30px', borderRadius:'6px', background:'#fff', boxShadow:'var(--shadow-xs)', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--primary-600)', fontSize:'16px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="monitor" /></span></span><span style={{width:'32px', height:'30px', borderRadius:'6px', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--text-muted)', fontSize:'16px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="smartphone" /></span></span></div>
          <div style={{display:'flex', alignItems:'center', gap:'7px', height:'36px', padding:'0 13px', borderRadius:'8px', border:'1px solid var(--border-default)', color:'var(--text-body)', fontSize:'13px', fontWeight:'600'}}><span style={{fontSize:'15px', display:'inline-flex', lineHeight:'0'}}><Icon name="eye" /></span>預覽</div>
          <div style={{display:'flex', alignItems:'center', gap:'7px', height:'36px', padding:'0 15px', borderRadius:'8px', background:'var(--primary-600)', color:'#fff', fontSize:'13px', fontWeight:'600'}}><span style={{fontSize:'15px', display:'inline-flex', lineHeight:'0'}}><Icon name="download" /></span>匯出範本</div>
        </div>
      </div>

      <div style={{display:'flex', height:'760px', background:'var(--surface-sunken)'}}>
        
        <aside style={{width:'270px', flex:'0 0 auto', background:'#fff', borderRight:'1px solid var(--border-subtle)', display:'flex', flexDirection:'column', padding:'16px 14px', overflow:'auto'}}>
          <div style={{fontSize:'11px', fontWeight:'700', letterSpacing:'.08em', textTransform:'uppercase', color:'var(--text-subtle)', margin:'2px 6px 10px'}}>活動類型</div>
          <div style={{display:'flex', alignItems:'center', gap:'10px', padding:'11px', borderRadius:'10px', background:'var(--primary-50)', border:'1px solid var(--primary-200)', marginBottom:'16px'}}><span style={{width:'34px', height:'34px', borderRadius:'8px', background:'var(--primary-600)', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'17px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="building-2" /></span></span><div><div style={{fontSize:'13px', fontWeight:'700', color:'var(--primary-800)'}}>城市探索</div><div style={{fontSize:'11px', color:'var(--primary-700)'}}>範本 · Urban Explorer</div></div></div>
          <div style={{fontSize:'11px', fontWeight:'700', letterSpacing:'.08em', textTransform:'uppercase', color:'var(--text-subtle)', margin:'2px 6px 10px'}}>內容區塊</div>
          <div style={{display:'flex', flexDirection:'column', gap:'7px'}}>
            <div style={{display:'flex', alignItems:'center', gap:'10px', padding:'10px 11px', borderRadius:'9px', border:'1.5px solid var(--primary-600)', background:'var(--primary-50)', fontSize:'13px', fontWeight:'600', color:'var(--primary-800)'}}><span style={{color:'var(--text-subtle)', fontSize:'15px', display:'inline-flex', lineHeight:'0'}}><Icon name="grip-vertical" /></span><span style={{fontSize:'15px', color:'var(--primary-600)', display:'inline-flex', lineHeight:'0'}}><Icon name="image" /></span>封面圖與標題<span style={{marginLeft:'auto', fontSize:'14px', color:'var(--primary-600)', display:'inline-flex', lineHeight:'0'}}><Icon name="pencil" /></span></div>
            <div style={{display:'flex', alignItems:'center', gap:'10px', padding:'10px 11px', borderRadius:'9px', border:'1px solid var(--border-subtle)', background:'#fff', fontSize:'13px', fontWeight:'500', color:'var(--text-body)'}}><span style={{color:'var(--text-subtle)', fontSize:'15px', display:'inline-flex', lineHeight:'0'}}><Icon name="grip-vertical" /></span><span style={{fontSize:'15px', color:'var(--text-muted)', display:'inline-flex', lineHeight:'0'}}><Icon name="type" /></span>活動介紹</div>
            <div style={{display:'flex', alignItems:'center', gap:'10px', padding:'10px 11px', borderRadius:'9px', border:'1px solid var(--border-subtle)', background:'#fff', fontSize:'13px', fontWeight:'500', color:'var(--text-body)'}}><span style={{color:'var(--text-subtle)', fontSize:'15px', display:'inline-flex', lineHeight:'0'}}><Icon name="grip-vertical" /></span><span style={{fontSize:'15px', color:'var(--text-muted)', display:'inline-flex', lineHeight:'0'}}><Icon name="map-pin" /></span>停靠點地圖</div>
            <div style={{display:'flex', alignItems:'center', gap:'10px', padding:'10px 11px', borderRadius:'9px', border:'1px solid var(--border-subtle)', background:'#fff', fontSize:'13px', fontWeight:'500', color:'var(--text-body)'}}><span style={{color:'var(--text-subtle)', fontSize:'15px', display:'inline-flex', lineHeight:'0'}}><Icon name="grip-vertical" /></span><span style={{fontSize:'15px', color:'var(--text-muted)', display:'inline-flex', lineHeight:'0'}}><Icon name="list-checks" /></span>任務清單</div>
            <div style={{display:'flex', alignItems:'center', gap:'10px', padding:'10px 11px', borderRadius:'9px', border:'1px solid var(--border-subtle)', background:'#fff', fontSize:'13px', fontWeight:'500', color:'var(--text-body)'}}><span style={{color:'var(--text-subtle)', fontSize:'15px', display:'inline-flex', lineHeight:'0'}}><Icon name="grip-vertical" /></span><span style={{fontSize:'15px', color:'var(--text-muted)', display:'inline-flex', lineHeight:'0'}}><Icon name="award" /></span>集章獎勵</div>
          </div>
          <div style={{display:'flex', alignItems:'center', justifyContent:'center', gap:'8px', marginTop:'12px', padding:'10px', borderRadius:'9px', border:'1.5px dashed var(--border-default)', color:'var(--text-muted)', fontSize:'13px', fontWeight:'600'}}><span style={{fontSize:'15px', display:'inline-flex', lineHeight:'0'}}><Icon name="plus" /></span>新增區塊</div>
        </aside>

        
        <div style={{flex:'1', minWidth:'0', overflow:'auto', padding:'26px', display:'flex', justifyContent:'center'}}>
          <div style={{width:'640px', background:'#fff', borderRadius:'14px', overflow:'hidden', boxShadow:'var(--shadow-lg)', border:'1px solid var(--border-subtle)'}}>
            <div style={{height:'280px', background:'linear-gradient(150deg,#134E61,#0B2935)', position:'relative', display:'flex', flexDirection:'column', justifyContent:'flex-end', padding:'26px', color:'#fff'}}>
              <div style={{position:'absolute', inset:'0', background:'radial-gradient(circle at 78% 20%,rgba(56,176,214,.35),transparent 55%)'}}></div>
              <div style={{position:'absolute', top:'18px', left:'18px', display:'flex', alignItems:'center', gap:'8px', fontSize:'12px', fontWeight:'700'}}><span style={{width:'26px', height:'26px', borderRadius:'7px', background:'rgba(255,255,255,.15)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'14px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="scan-line" /></span></span>府城巡禮</div>
              <div style={{position:'absolute', top:'18px', right:'18px', display:'flex', alignItems:'center', gap:'6px', fontSize:'11px', fontWeight:'600', background:'rgba(255,255,255,.12)', padding:'6px 11px', borderRadius:'9999px', backdropFilter:'blur(4px)'}}><span style={{width:'7px', height:'7px', borderRadius:'50%', background:'#28C840'}}></span>進行中</div>
              <div style={{position:'relative', fontSize:'12px', fontWeight:'700', letterSpacing:'.1em', color:'#6FCDE8', textTransform:'uppercase', marginBottom:'8px'}}>城市探索 · 台南府城</div>
              <div style={{position:'relative', fontSize:'34px', fontWeight:'800', lineHeight:'1.1', letterSpacing:'-.02em', maxWidth:'16ch'}}>台南府城古蹟巡禮 2025</div>
              <div style={{position:'relative', display:'flex', gap:'10px', marginTop:'18px'}}><span style={{display:'inline-flex', alignItems:'center', gap:'8px', padding:'11px 20px', borderRadius:'9999px', background:'#fff', color:'var(--primary-800)', fontSize:'14px', fontWeight:'700'}}><span style={{fontSize:'16px', display:'inline-flex', lineHeight:'0'}}><Icon name="qr-code" /></span>開始旅程</span><span style={{display:'inline-flex', alignItems:'center', gap:'8px', padding:'11px 18px', borderRadius:'9999px', background:'rgba(255,255,255,.12)', color:'#fff', fontSize:'14px', fontWeight:'600', border:'1px solid rgba(255,255,255,.25)'}}>查看地圖</span></div>
            </div>
            <div style={{padding:'24px 26px'}}>
              <div style={{display:'flex', gap:'12px', marginBottom:'22px'}}>
                <div style={{flex:'1', textAlign:'center', padding:'14px', borderRadius:'10px', background:'var(--surface-sunken)'}}><div style={{fontSize:'22px', fontWeight:'800', color:'var(--text-strong)'}}>12</div><div style={{fontSize:'11px', color:'var(--text-muted)', fontWeight:'600'}}>停靠點</div></div>
                <div style={{flex:'1', textAlign:'center', padding:'14px', borderRadius:'10px', background:'var(--surface-sunken)'}}><div style={{fontSize:'22px', fontWeight:'800', color:'var(--text-strong)'}}>6</div><div style={{fontSize:'11px', color:'var(--text-muted)', fontWeight:'600'}}>印章</div></div>
                <div style={{flex:'1', textAlign:'center', padding:'14px', borderRadius:'10px', background:'var(--surface-sunken)'}}><div style={{fontSize:'22px', fontWeight:'800', color:'var(--text-strong)'}}>~90 分</div><div style={{fontSize:'11px', color:'var(--text-muted)', fontWeight:'600'}}>時長</div></div>
              </div>
              <div style={{fontSize:'16px', fontWeight:'800', color:'var(--text-strong)', marginBottom:'12px'}}>熱門停靠點</div>
              <div style={{display:'flex', flexDirection:'column', gap:'10px'}}>
                <div style={{display:'flex', alignItems:'center', gap:'13px', padding:'13px', borderRadius:'11px', border:'1px solid var(--border-subtle)'}}><span style={{width:'40px', height:'40px', borderRadius:'9px', background:'var(--primary-50)', color:'var(--primary-600)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'19px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="map-pin" /></span></span><div style={{flex:'1'}}><div style={{fontWeight:'700', fontSize:'14px', color:'var(--text-strong)'}}>赤崁樓</div><div style={{fontSize:'12px', color:'var(--text-muted)'}}>掃描 QR 開啟 AR 模型</div></div><span style={{fontSize:'16px', color:'var(--text-subtle)', display:'inline-flex', lineHeight:'0'}}><Icon name="chevron-right" /></span></div>
                <div style={{display:'flex', alignItems:'center', gap:'13px', padding:'13px', borderRadius:'11px', border:'1px solid var(--border-subtle)'}}><span style={{width:'40px', height:'40px', borderRadius:'9px', background:'var(--primary-50)', color:'var(--primary-600)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'19px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="building-2" /></span></span><div style={{flex:'1'}}><div style={{fontWeight:'700', fontSize:'14px', color:'var(--text-strong)'}}>安平古堡</div><div style={{fontSize:'12px', color:'var(--text-muted)'}}>GPS + AR 定位點</div></div><span style={{fontSize:'16px', color:'var(--text-subtle)', display:'inline-flex', lineHeight:'0'}}><Icon name="chevron-right" /></span></div>
              </div>
            </div>
          </div>
        </div>

        
        <aside style={{width:'290px', flex:'0 0 auto', background:'#fff', borderLeft:'1px solid var(--border-subtle)', padding:'18px 16px', overflow:'auto'}}>
          <div style={{fontSize:'13px', fontWeight:'800', color:'var(--text-strong)', marginBottom:'4px'}}>封面圖與標題</div>
          <div style={{fontSize:'11.5px', color:'var(--text-muted)', marginBottom:'16px'}}>編輯選取的區塊</div>
          <label style={{fontSize:'12px', fontWeight:'600', color:'var(--text-body)', display:'block', marginBottom:'6px'}}>標題</label>
          <div style={{height:'40px', border:'1px solid var(--border-default)', borderRadius:'8px', display:'flex', alignItems:'center', padding:'0 12px', fontSize:'13px', color:'var(--text-strong)', fontWeight:'600', marginBottom:'14px'}}>台南府城古蹟巡禮 2025</div>
          <label style={{fontSize:'12px', fontWeight:'600', color:'var(--text-body)', display:'block', marginBottom:'6px'}}>eyebrow 標籤</label>
          <div style={{height:'40px', border:'1px solid var(--border-default)', borderRadius:'8px', display:'flex', alignItems:'center', padding:'0 12px', fontSize:'13px', color:'var(--text-body)', marginBottom:'14px'}}>城市探索 · 台南府城</div>
          <label style={{fontSize:'12px', fontWeight:'600', color:'var(--text-body)', display:'block', marginBottom:'6px'}}>封面圖</label>
          <div style={{height:'104px', border:'1.5px dashed var(--border-default)', borderRadius:'10px', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:'6px', color:'var(--text-muted)', background:'var(--surface-sunken)', marginBottom:'16px'}}><span style={{fontSize:'22px', display:'inline-flex', lineHeight:'0'}}><Icon name="upload" /></span><span style={{fontSize:'12px', fontWeight:'600'}}>將圖片拖曳至此</span><span style={{fontSize:'10.5px'}}>JPG/PNG · 最大 5MB</span></div>
          <label style={{fontSize:'12px', fontWeight:'600', color:'var(--text-body)', display:'block', marginBottom:'8px'}}>主要行動按鈕</label>
          <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', padding:'11px 13px', borderRadius:'9px', background:'var(--surface-sunken)', fontSize:'12.5px', fontWeight:'600', color:'var(--text-body)'}}>顯示「開始」按鈕<span style={{width:'38px', height:'22px', borderRadius:'9999px', background:'var(--primary-600)', position:'relative'}}><span style={{position:'absolute', top:'2px', right:'2px', width:'18px', height:'18px', borderRadius:'50%', background:'#fff'}}></span></span></div>
        </aside>
      </div>
    </div>
      <div style={{display:'flex', alignItems:'center', gap:'8px', color:'#8FB6C2', fontSize:'12.5px', fontWeight:'600', paddingLeft:'4px'}}><span style={{width:'18px', height:'18px', borderRadius:'9999px', background:'rgba(255,255,255,.12)', color:'#6FCDE8', display:'inline-flex', alignItems:'center', justifyContent:'center', fontSize:'10px', fontWeight:'700'}}>2</span>Tùy chỉnh nội dung kéo–thả &amp; xuất template</div>
    </div>

    
    <div style={{width:'340px', flex:'0 0 auto', background:'#0B2935', borderRadius:'44px', padding:'11px', boxShadow:'var(--shadow-xl)', border:'1px solid rgba(0,0,0,.3)'}}>
      <div style={{borderRadius:'34px', overflow:'hidden', background:'#fff', position:'relative', height:'720px', display:'flex', flexDirection:'column'}}>
        <div style={{position:'absolute', top:'0', left:'0', right:'0', height:'34px', display:'flex', alignItems:'center', justifyContent:'space-between', padding:'10px 26px 0', fontSize:'12px', fontWeight:'700', color:'#fff', zIndex:'5'}}><span>9:41</span><span style={{width:'110px', height:'26px', background:'#0B2935', borderRadius:'0 0 16px 16px', position:'absolute', left:'50%', transform:'translateX(-50%)', top:'0'}}></span><span style={{display:'flex', gap:'5px', fontSize:'13px'}}><Icon name="signal-high" /><Icon name="wifi" /><Icon name="battery-full" /></span></div>
        <div style={{flex:'1', overflow:'auto'}}>
          <div style={{height:'330px', background:'linear-gradient(160deg,#134E61,#0B2935)', position:'relative', display:'flex', flexDirection:'column', justifyContent:'flex-end', padding:'20px', color:'#fff'}}>
            <div style={{position:'absolute', inset:'0', background:'radial-gradient(circle at 80% 15%,rgba(56,176,214,.4),transparent 55%)'}}></div>
            <div style={{position:'absolute', top:'44px', left:'16px', display:'flex', alignItems:'center', gap:'7px', fontSize:'11px', fontWeight:'700'}}><span style={{width:'24px', height:'24px', borderRadius:'7px', background:'rgba(255,255,255,.15)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'13px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="scan-line" /></span></span>府城巡禮</div>
            <div style={{position:'relative', fontSize:'11px', fontWeight:'700', letterSpacing:'.1em', color:'#6FCDE8', textTransform:'uppercase', marginBottom:'7px'}}>城市探索 · 台南府城</div>
            <div style={{position:'relative', fontSize:'27px', fontWeight:'800', lineHeight:'1.12', letterSpacing:'-.02em'}}>台南府城古蹟巡禮 2025</div>
            <div style={{position:'relative', display:'inline-flex', alignItems:'center', justifyContent:'center', gap:'8px', marginTop:'16px', padding:'13px', borderRadius:'9999px', background:'#fff', color:'var(--primary-800)', fontSize:'14px', fontWeight:'700'}}><span style={{fontSize:'16px', display:'inline-flex', lineHeight:'0'}}><Icon name="qr-code" /></span>開始旅程</div>
          </div>
          <div style={{padding:'18px 16px'}}>
            <div style={{display:'flex', gap:'9px', marginBottom:'18px'}}>
              <div style={{flex:'1', textAlign:'center', padding:'11px', borderRadius:'10px', background:'var(--surface-sunken)'}}><div style={{fontSize:'18px', fontWeight:'800', color:'var(--text-strong)'}}>12</div><div style={{fontSize:'10px', color:'var(--text-muted)', fontWeight:'600'}}>停靠點</div></div>
              <div style={{flex:'1', textAlign:'center', padding:'11px', borderRadius:'10px', background:'var(--surface-sunken)'}}><div style={{fontSize:'18px', fontWeight:'800', color:'var(--text-strong)'}}>6</div><div style={{fontSize:'10px', color:'var(--text-muted)', fontWeight:'600'}}>印章</div></div>
              <div style={{flex:'1', textAlign:'center', padding:'11px', borderRadius:'10px', background:'var(--surface-sunken)'}}><div style={{fontSize:'18px', fontWeight:'800', color:'var(--text-strong)'}}>90 分</div><div style={{fontSize:'10px', color:'var(--text-muted)', fontWeight:'600'}}>時長</div></div>
            </div>
            <div style={{fontSize:'14px', fontWeight:'800', color:'var(--text-strong)', marginBottom:'11px'}}>熱門停靠點</div>
            <div style={{display:'flex', alignItems:'center', gap:'11px', padding:'12px', borderRadius:'11px', border:'1px solid var(--border-subtle)', marginBottom:'9px'}}><span style={{width:'36px', height:'36px', borderRadius:'9px', background:'var(--primary-50)', color:'var(--primary-600)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'17px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="map-pin" /></span></span><div style={{flex:'1'}}><div style={{fontWeight:'700', fontSize:'13px', color:'var(--text-strong)'}}>赤崁樓</div><div style={{fontSize:'11px', color:'var(--text-muted)'}}>掃描 QR 開啟 AR</div></div></div>
            <div style={{display:'flex', alignItems:'center', gap:'11px', padding:'12px', borderRadius:'11px', border:'1px solid var(--border-subtle)'}}><span style={{width:'36px', height:'36px', borderRadius:'9px', background:'var(--primary-50)', color:'var(--primary-600)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'17px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="building-2" /></span></span><div style={{flex:'1'}}><div style={{fontWeight:'700', fontSize:'13px', color:'var(--text-strong)'}}>安平古堡</div><div style={{fontSize:'11px', color:'var(--text-muted)'}}>GPS + AR</div></div></div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
  );
}
