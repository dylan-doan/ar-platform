import { Icon } from '../../components/Icon';

export const metadata = { title: 'WebAR 體驗 · Zoustec AR' };

export default function Page() {
  return (
<section id="s4" data-screen-label="04 Trải nghiệm WebAR (LINE LIFF)" style={{maxWidth:'1620px', margin:'0 auto', padding:'40px 48px 24px'}}>
  <div style={{display:'flex', alignItems:'baseline', gap:'16px', marginBottom:'6px'}}>
    <span style={{fontSize:'13px', fontWeight:'800', letterSpacing:'.14em', color:'#6FCDE8'}}>04</span>
    <h2 style={{margin:'0', fontSize:'30px', fontWeight:'800', letterSpacing:'-0.02em', color:'#fff'}}>Trải nghiệm WebAR &amp; nhiệm vụ · LINE LIFF</h2>
  </div>
  <p style={{margin:'0 0 28px', color:'#8FB6C2', fontSize:'15px', maxWidth:'76ch'}}>Người tham gia vào từ LINE (LIFF), tự động đăng nhập, hoàn thành nhiệm vụ QR / GPS + AR, và thu thập con dấu — không cần tải ứng dụng.</p>

  <div style={{display:'flex', gap:'28px', alignItems:'flex-start', flexWrap:'wrap'}}>

    
    <div style={{width:'304px', flex:'0 0 auto'}}>
      <div style={{background:'#0B2935', borderRadius:'42px', padding:'10px', boxShadow:'var(--shadow-xl)', border:'1px solid rgba(0,0,0,.3)'}}>
        <div style={{borderRadius:'33px', overflow:'hidden', background:'#fff', position:'relative', height:'648px', display:'flex', flexDirection:'column'}}>
          <div style={{height:'30px', background:'#06C755', display:'flex', alignItems:'center', justifyContent:'space-between', padding:'8px 22px 0', fontSize:'11px', fontWeight:'700', color:'#fff'}}><span>9:41</span><span style={{display:'flex', gap:'5px', fontSize:'12px'}}><Icon name="signal-high" /><Icon name="wifi" /><Icon name="battery-full" /></span></div>
          <div style={{height:'40px', background:'#06C755', display:'flex', alignItems:'center', padding:'0 14px', gap:'9px', color:'#fff'}}><span style={{fontSize:'17px', display:'inline-flex', lineHeight:'0'}}><Icon name="chevron-left" /></span><span style={{fontWeight:'800', fontSize:'14px', letterSpacing:'-.01em'}}>LINE</span><span style={{fontSize:'12px', opacity:'.85', fontWeight:'600'}}>· 府城巡禮</span><span style={{marginLeft:'auto', fontSize:'17px', display:'inline-flex', lineHeight:'0'}}><Icon name="x" /></span></div>
          <div style={{flex:'1', display:'flex', flexDirection:'column', background:'linear-gradient(180deg,#0B2935,#134E61)', color:'#fff', padding:'30px 22px', position:'relative'}}>
            <div style={{position:'absolute', inset:'0', background:'radial-gradient(circle at 70% 12%,rgba(56,176,214,.35),transparent 55%)'}}></div>
            <div style={{position:'relative', marginTop:'14px', width:'64px', height:'64px', borderRadius:'18px', background:'linear-gradient(145deg,#38B0D6,#0E7490)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'30px', boxShadow:'0 14px 30px rgba(0,0,0,.35)'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="scan-line" /></span></div>
            <div style={{position:'relative', fontSize:'12px', fontWeight:'700', letterSpacing:'.12em', textTransform:'uppercase', color:'#6FCDE8', marginTop:'24px'}}>城市探索 · 台南府城</div>
            <div style={{position:'relative', fontSize:'29px', fontWeight:'800', lineHeight:'1.12', letterSpacing:'-.02em', marginTop:'8px'}}>台南府城古蹟巡禮 2025</div>
            <div style={{position:'relative', fontSize:'14px', color:'#B6D4DE', lineHeight:'1.55', marginTop:'12px'}}>造訪 12 個歷史停靠點，掃描 AR 並收集 6 枚府城印章。</div>
            <div style={{position:'relative', marginTop:'auto', display:'flex', alignItems:'center', gap:'11px', padding:'12px', borderRadius:'14px', background:'rgba(255,255,255,.08)', border:'1px solid rgba(255,255,255,.14)'}}><div style={{width:'38px', height:'38px', borderRadius:'9999px', background:'#6FCDE8', color:'#0B2935', display:'flex', alignItems:'center', justifyContent:'center', fontWeight:'800', fontSize:'14px'}}>美安</div><div style={{flex:'1', minWidth:'0'}}><div style={{fontSize:'13px', fontWeight:'700'}}>陳美安</div><div style={{fontSize:'11px', color:'#8FB6C2'}}>透過 LINE 自動登入</div></div><span style={{color:'var(--success-500)', fontSize:'18px', display:'inline-flex', lineHeight:'0'}}><Icon name="circle-check" /></span></div>
            <div style={{position:'relative', marginTop:'12px', display:'flex', alignItems:'center', justifyContent:'center', gap:'9px', height:'52px', borderRadius:'9999px', background:'#fff', color:'var(--primary-800)', fontSize:'16px', fontWeight:'800'}}><span style={{fontSize:'18px', display:'inline-flex', lineHeight:'0'}}><Icon name="play" /></span>開始旅程</div>
          </div>
        </div>
      </div>
      <div style={{textAlign:'center', color:'#8FB6C2', fontSize:'12.5px', fontWeight:'600', marginTop:'14px'}}>Vào &amp; đăng nhập LIFF</div>
    </div>

    
    <div style={{width:'304px', flex:'0 0 auto'}}>
      <div style={{background:'#0B2935', borderRadius:'42px', padding:'10px', boxShadow:'var(--shadow-xl)', border:'1px solid rgba(0,0,0,.3)'}}>
        <div style={{borderRadius:'33px', overflow:'hidden', background:'#fff', position:'relative', height:'648px', display:'flex', flexDirection:'column'}}>
          <div style={{height:'30px', background:'#EEF2F6', display:'flex', alignItems:'center', justifyContent:'space-between', padding:'8px 22px 0', fontSize:'11px', fontWeight:'700', color:'var(--text-strong)'}}><span>9:41</span><span style={{display:'flex', gap:'5px', fontSize:'12px'}}><Icon name="signal-high" /><Icon name="wifi" /><Icon name="battery-full" /></span></div>
          
          <div style={{height:'290px', position:'relative', background:'#E7EFEA', overflow:'hidden'}}>
            <svg viewBox="0 0 304 290" width="100%" height="290" style={{position:'absolute', inset:'0'}}><rect width="304" height="290" fill="#DDE9E2"/><path d="M-10,80 C80,60 120,140 220,120 S330,150 330,150" fill="none" stroke="#C3D6CB" strokeWidth="26"/><path d="M40,-10 C60,80 20,150 90,220 S130,320 150,320" fill="none" stroke="#C3D6CB" strokeWidth="20"/><path d="M0,200 L304,215" stroke="#CBD9D0" strokeWidth="3"/><rect x="30" y="150" width="70" height="54" rx="6" fill="#CFDDD4"/><rect x="180" y="60" width="60" height="46" rx="6" fill="#CFDDD4"/><path d="M20,40 Q90,120 160,90 T300,110" fill="none" stroke="#0E7490" strokeWidth="3" strokeDasharray="2 7" strokeLinecap="round"/></svg>
            <div style={{position:'absolute', top:'44px', left:'12px', right:'12px', display:'flex', alignItems:'center', gap:'9px', height:'42px', background:'#fff', borderRadius:'12px', boxShadow:'var(--shadow-md)', padding:'0 13px'}}><span style={{color:'var(--primary-600)', fontSize:'17px', display:'inline-flex', lineHeight:'0'}}><Icon name="navigation" /></span><span style={{fontSize:'13px', fontWeight:'700', color:'var(--text-strong)'}}>行程地圖</span><span style={{marginLeft:'auto', fontSize:'11px', fontWeight:'700', color:'var(--primary-600)', background:'var(--primary-50)', padding:'4px 9px', borderRadius:'9999px'}}>3 / 12</span></div>
            <div style={{position:'absolute', top:'120px', left:'88px', width:'34px', height:'34px', borderRadius:'9999px', background:'var(--success-500)', border:'3px solid #fff', boxShadow:'var(--shadow-md)', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontSize:'15px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="check" /></span></div>
            <div style={{position:'absolute', top:'82px', left:'190px', width:'40px', height:'40px', borderRadius:'9999px', background:'var(--primary-600)', border:'3px solid #fff', boxShadow:'var(--shadow-lg)', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontSize:'17px', animation:'none'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="map-pin" /></span></div>
            <div style={{position:'absolute', top:'186px', left:'150px', width:'32px', height:'32px', borderRadius:'9999px', background:'var(--neutral-400)', border:'3px solid #fff', boxShadow:'var(--shadow-md)', display:'flex', alignItems:'center', justifyContent:'center', color:'#fff', fontSize:'14px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="lock" /></span></div>
          </div>
          
          <div style={{flex:'1', background:'#fff', borderRadius:'20px 20px 0 0', marginTop:'-18px', position:'relative', padding:'14px 16px 16px', overflow:'auto'}}>
            <div style={{width:'38px', height:'4px', borderRadius:'9999px', background:'var(--neutral-300)', margin:'0 auto 14px'}}></div>
            <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:'12px'}}><div style={{fontSize:'15px', fontWeight:'800', color:'var(--text-strong)'}}>任務</div><div style={{fontSize:'12px', fontWeight:'700', color:'var(--text-muted)'}}>3/12 完成</div></div>
            <div style={{height:'7px', borderRadius:'9999px', background:'var(--surface-sunken)', marginBottom:'16px', position:'relative'}}><span style={{position:'absolute', left:'0', top:'0', height:'7px', width:'25%', borderRadius:'9999px', background:'var(--primary-600)'}}></span></div>
            <div style={{display:'flex', alignItems:'center', gap:'12px', padding:'12px', borderRadius:'12px', border:'1.5px solid var(--primary-600)', background:'var(--primary-50)', marginBottom:'9px'}}><span style={{width:'40px', height:'40px', borderRadius:'10px', background:'var(--primary-600)', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'18px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="qr-code" /></span></span><div style={{flex:'1'}}><div style={{fontSize:'13.5px', fontWeight:'700', color:'var(--primary-900)'}}>安平古堡</div><div style={{fontSize:'11.5px', color:'var(--primary-700)'}}>QR + AR · 距離 40m</div></div><span style={{fontSize:'11px', fontWeight:'800', color:'#fff', background:'var(--primary-600)', padding:'5px 10px', borderRadius:'9999px'}}>前往</span></div>
            <div style={{display:'flex', alignItems:'center', gap:'12px', padding:'12px', borderRadius:'12px', border:'1px solid var(--border-subtle)', marginBottom:'9px'}}><span style={{width:'40px', height:'40px', borderRadius:'10px', background:'var(--income-bg,var(--success-50))', color:'var(--success-600)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'18px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="badge-check" /></span></span><div style={{flex:'1'}}><div style={{fontSize:'13.5px', fontWeight:'700', color:'var(--text-strong)'}}>赤崁樓</div><div style={{fontSize:'11.5px', color:'var(--success-600)', fontWeight:'600'}}>已完成</div></div></div>
            <div style={{display:'flex', alignItems:'center', gap:'12px', padding:'12px', borderRadius:'12px', border:'1px solid var(--border-subtle)', opacity:'.6'}}><span style={{width:'40px', height:'40px', borderRadius:'10px', background:'var(--surface-sunken)', color:'var(--text-muted)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'18px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="lock" /></span></span><div style={{flex:'1'}}><div style={{fontSize:'13.5px', fontWeight:'700', color:'var(--text-body)'}}>孔子廟</div><div style={{fontSize:'11.5px', color:'var(--text-muted)'}}>靠近時解鎖</div></div></div>
          </div>
        </div>
      </div>
      <div style={{textAlign:'center', color:'#8FB6C2', fontSize:'12.5px', fontWeight:'600', marginTop:'14px'}}>Bản đồ &amp; danh sách nhiệm vụ</div>
    </div>

    
    <div style={{width:'304px', flex:'0 0 auto'}}>
      <div style={{background:'#0B2935', borderRadius:'42px', padding:'10px', boxShadow:'var(--shadow-xl)', border:'1px solid rgba(0,0,0,.3)'}}>
        <div style={{borderRadius:'33px', overflow:'hidden', background:'#000', position:'relative', height:'648px', display:'flex', flexDirection:'column'}}>
          <div style={{position:'absolute', inset:'0', background:'linear-gradient(180deg,#243447,#0d1620 60%,#1a2733)'}}></div>
          <div style={{position:'absolute', inset:'0', background:'radial-gradient(circle at 50% 42%,rgba(56,176,214,.14),transparent 60%)'}}></div>
          
          <div style={{position:'relative', height:'30px', display:'flex', alignItems:'center', justifyContent:'space-between', padding:'8px 22px 0', fontSize:'11px', fontWeight:'700', color:'#fff'}}><span>9:41</span><span style={{display:'flex', gap:'5px', fontSize:'12px'}}><Icon name="signal-high" /><Icon name="wifi" /><Icon name="battery-full" /></span></div>
          <div style={{position:'relative', display:'flex', alignItems:'center', gap:'9px', padding:'10px 14px'}}><span style={{width:'34px', height:'34px', borderRadius:'9999px', background:'rgba(255,255,255,.12)', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'16px', backdropFilter:'blur(6px)'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="chevron-left" /></span></span><div style={{display:'flex', alignItems:'center', gap:'7px', background:'rgba(255,255,255,.12)', padding:'7px 12px', borderRadius:'9999px', color:'#fff', fontSize:'12px', fontWeight:'600', backdropFilter:'blur(6px)'}}><span style={{width:'7px', height:'7px', borderRadius:'50%', background:'var(--danger-500)'}}></span>AR · 安平古堡</div></div>
          
          <div style={{position:'relative', flex:'1', display:'flex', alignItems:'center', justifyContent:'center'}}>
            <div style={{position:'absolute', width:'230px', height:'230px', borderRadius:'24px', border:'2px dashed rgba(255,255,255,.35)'}}></div>
            <span style={{position:'absolute', top:'calc(50% - 130px)', left:'calc(50% - 128px)', width:'26px', height:'26px', borderTop:'3px solid #6FCDE8', borderLeft:'3px solid #6FCDE8', borderRadius:'6px 0 0 0'}}></span>
            <span style={{position:'absolute', top:'calc(50% - 130px)', right:'calc(50% - 128px)', width:'26px', height:'26px', borderTop:'3px solid #6FCDE8', borderRight:'3px solid #6FCDE8', borderRadius:'0 6px 0 0'}}></span>
            <span style={{position:'absolute', bottom:'calc(50% - 130px)', left:'calc(50% - 128px)', width:'26px', height:'26px', borderBottom:'3px solid #6FCDE8', borderLeft:'3px solid #6FCDE8', borderRadius:'0 0 0 6px'}}></span>
            <span style={{position:'absolute', bottom:'calc(50% - 130px)', right:'calc(50% - 128px)', width:'26px', height:'26px', borderBottom:'3px solid #6FCDE8', borderRight:'3px solid #6FCDE8', borderRadius:'0 0 6px 0'}}></span>
            <div style={{position:'relative', display:'flex', flexDirection:'column', alignItems:'center'}}>
              <div style={{width:'56px', height:'14px', borderRadius:'50%', background:'rgba(0,0,0,.4)', filter:'blur(5px)', position:'absolute', bottom:'-10px'}}></div>
              <div style={{width:'118px', height:'118px', borderRadius:'26px', background:'linear-gradient(150deg,#38B0D6,#0E7490)', boxShadow:'0 20px 40px rgba(0,0,0,.5),inset 0 2px 10px rgba(255,255,255,.4)', display:'flex', alignItems:'center', justifyContent:'center', transform:'rotate(-8deg)'}}><span style={{fontSize:'64px', color:'rgba(255,255,255,.92)', display:'inline-flex', lineHeight:'0', transform:'rotate(8deg)'}}><Icon name="box" /></span></div>
            </div>
          </div>
          
          <div style={{position:'relative', textAlign:'center', color:'#fff', fontSize:'13px', fontWeight:'600', padding:'0 30px', marginBottom:'16px', textShadow:'0 1px 6px rgba(0,0,0,.5)'}}>移動相機，將吉祥物放置在御龜碑上</div>
          
          <div style={{position:'relative', display:'flex', alignItems:'center', justifyContent:'center', gap:'34px', paddingBottom:'30px'}}>
            <span style={{width:'46px', height:'46px', borderRadius:'9999px', background:'rgba(255,255,255,.14)', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'19px', backdropFilter:'blur(6px)'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="rotate-3d" /></span></span>
            <span style={{width:'74px', height:'74px', borderRadius:'9999px', background:'#fff', border:'5px solid rgba(255,255,255,.4)', display:'flex', alignItems:'center', justifyContent:'center', color:'var(--primary-700)', fontSize:'28px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="camera" /></span></span>
            <span style={{width:'46px', height:'46px', borderRadius:'9999px', background:'rgba(255,255,255,.14)', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'19px', backdropFilter:'blur(6px)'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="share-2" /></span></span>
          </div>
        </div>
      </div>
      <div style={{textAlign:'center', color:'#8FB6C2', fontSize:'12.5px', fontWeight:'600', marginTop:'14px'}}>Trải nghiệm WebAR</div>
    </div>

    
    <div style={{width:'304px', flex:'0 0 auto'}}>
      <div style={{background:'#0B2935', borderRadius:'42px', padding:'10px', boxShadow:'var(--shadow-xl)', border:'1px solid rgba(0,0,0,.3)'}}>
        <div style={{borderRadius:'33px', overflow:'hidden', background:'var(--surface-app)', position:'relative', height:'648px', display:'flex', flexDirection:'column'}}>
          <div style={{height:'30px', background:'#fff', display:'flex', alignItems:'center', justifyContent:'space-between', padding:'8px 22px 0', fontSize:'11px', fontWeight:'700', color:'var(--text-strong)'}}><span>9:41</span><span style={{display:'flex', gap:'5px', fontSize:'12px'}}><Icon name="signal-high" /><Icon name="wifi" /><Icon name="battery-full" /></span></div>
          
          <div style={{background:'linear-gradient(150deg,#134E61,#0B2935)', padding:'24px 20px 26px', color:'#fff', position:'relative', textAlign:'center'}}>
            <div style={{position:'absolute', inset:'0', background:'radial-gradient(circle at 50% 30%,rgba(56,176,214,.35),transparent 60%)'}}></div>
            <div style={{position:'relative', width:'80px', height:'80px', borderRadius:'9999px', background:'linear-gradient(145deg,#FEBC2E,#D97706)', margin:'6px auto 0', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'40px', boxShadow:'0 14px 30px rgba(0,0,0,.4),inset 0 2px 10px rgba(255,255,255,.4)', color:'#fff'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="award" /></span></div>
            <div style={{position:'relative', fontSize:'12px', fontWeight:'700', letterSpacing:'.12em', textTransform:'uppercase', color:'#6FCDE8', marginTop:'16px'}}>獲得新印章！</div>
            <div style={{position:'relative', fontSize:'22px', fontWeight:'800', marginTop:'5px'}}>安平古堡</div>
            <div style={{position:'relative', fontSize:'13px', color:'#B6D4DE', marginTop:'5px'}}>你已收集 4 / 6 枚印章</div>
          </div>
          
          <div style={{flex:'1', padding:'18px 16px', overflow:'auto'}}>
            <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:'14px'}}><div style={{fontSize:'14px', fontWeight:'800', color:'var(--text-strong)'}}>集章冊</div><div style={{fontSize:'12px', fontWeight:'700', color:'var(--primary-600)'}}>4/6</div></div>
            <div style={{display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'11px'}}>
              <div style={{aspectRatio:'1', borderRadius:'14px', background:'var(--primary-50)', border:'1.5px solid var(--primary-200)', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:'4px', color:'var(--primary-600)'}}><span style={{fontSize:'26px', display:'inline-flex', lineHeight:'0'}}><Icon name="building-2" /></span><span style={{fontSize:'9.5px', fontWeight:'700', color:'var(--primary-800)'}}>赤崁樓</span></div>
              <div style={{aspectRatio:'1', borderRadius:'14px', background:'var(--primary-50)', border:'1.5px solid var(--primary-200)', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:'4px', color:'var(--primary-600)'}}><span style={{fontSize:'26px', display:'inline-flex', lineHeight:'0'}}><Icon name="map-pin" /></span><span style={{fontSize:'9.5px', fontWeight:'700', color:'var(--primary-800)'}}>孔子廟</span></div>
              <div style={{aspectRatio:'1', borderRadius:'14px', background:'var(--primary-50)', border:'1.5px solid var(--primary-200)', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:'4px', color:'var(--primary-600)'}}><span style={{fontSize:'26px', display:'inline-flex', lineHeight:'0'}}><Icon name="scan-line" /></span><span style={{fontSize:'9.5px', fontWeight:'700', color:'var(--primary-800)'}}>大天后宮</span></div>
              <div style={{aspectRatio:'1', borderRadius:'14px', background:'linear-gradient(145deg,#FEF3C7,#FDE68A)', border:'1.5px solid #FBBF24', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:'4px', color:'#B45309', boxShadow:'0 0 0 3px rgba(251,191,36,.25)'}}><span style={{fontSize:'26px', display:'inline-flex', lineHeight:'0'}}><Icon name="award" /></span><span style={{fontSize:'9.5px', fontWeight:'800'}}>安平古堡</span></div>
              <div style={{aspectRatio:'1', borderRadius:'14px', background:'var(--surface-sunken)', border:'1.5px dashed var(--border-default)', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:'4px', color:'var(--text-subtle)'}}><span style={{fontSize:'24px', display:'inline-flex', lineHeight:'0'}}><Icon name="lock" /></span><span style={{fontSize:'9.5px', fontWeight:'600'}}>億載金城</span></div>
              <div style={{aspectRatio:'1', borderRadius:'14px', background:'var(--surface-sunken)', border:'1.5px dashed var(--border-default)', display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', gap:'4px', color:'var(--text-subtle)'}}><span style={{fontSize:'24px', display:'inline-flex', lineHeight:'0'}}><Icon name="lock" /></span><span style={{fontSize:'9.5px', fontWeight:'600'}}>延平郡王祠</span></div>
            </div>
            <div style={{display:'flex', gap:'9px', marginTop:'16px'}}>
              <div style={{flex:'1', display:'flex', alignItems:'center', justifyContent:'center', gap:'7px', height:'46px', borderRadius:'9999px', background:'var(--primary-600)', color:'#fff', fontSize:'13.5px', fontWeight:'700'}}><span style={{fontSize:'16px', display:'inline-flex', lineHeight:'0'}}><Icon name="navigation" /></span>下一個地點</div>
              <div style={{width:'46px', height:'46px', borderRadius:'9999px', background:'#fff', border:'1px solid var(--border-default)', color:'var(--text-body)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'17px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="share-2" /></span></div>
            </div>
          </div>
        </div>
      </div>
      <div style={{textAlign:'center', color:'#8FB6C2', fontSize:'12.5px', fontWeight:'600', marginTop:'14px'}}>Thu thập con dấu &amp; phần thưởng</div>
    </div>
  </div>
</section>
  );
}
