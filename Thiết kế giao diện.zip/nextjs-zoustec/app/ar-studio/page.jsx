import { Icon } from '../../components/Icon';

export const metadata = { title: 'AI 3D 生成工具 · Zoustec AR' };

export default function Page() {
  return (
<section id="s3" data-screen-label="03 Công cụ tạo 3D bằng AI" style={{maxWidth:'1620px', margin:'0 auto', padding:'40px 48px 24px'}}>
  <div style={{display:'flex', alignItems:'baseline', gap:'16px', marginBottom:'6px'}}>
    <span style={{fontSize:'13px', fontWeight:'800', letterSpacing:'.14em', color:'#6FCDE8'}}>03</span>
    <h2 style={{margin:'0', fontSize:'30px', fontWeight:'800', letterSpacing:'-0.02em', color:'#fff'}}>Công cụ tạo nội dung 3D bằng AI</h2>
  </div>
  <p style={{margin:'0 0 28px', color:'#8FB6C2', fontSize:'15px', maxWidth:'74ch'}}>Nhân sự phi kỹ thuật tải ảnh 2D (linh vật / nhân vật) → AI tự dựng mô hình 3D → điều chỉnh màu sắc, tỷ lệ → xuất sang WebAR. Mục tiêu: giảm rào cản tạo nội dung AR.</p>

  <div style={{width:'1280px', borderRadius:'16px', overflow:'hidden', boxShadow:'var(--shadow-xl)', border:'1px solid rgba(0,0,0,.2)', background:'#fff'}}>
    <div style={{height:'40px', background:'#0B2935', display:'flex', alignItems:'center', gap:'8px', padding:'0 16px'}}>
      <span style={{width:'11px', height:'11px', borderRadius:'50%', background:'#FF5F57'}}></span><span style={{width:'11px', height:'11px', borderRadius:'50%', background:'#FEBC2E'}}></span><span style={{width:'11px', height:'11px', borderRadius:'50%', background:'#28C840'}}></span>
      <div style={{marginLeft:'14px', flex:'1', maxWidth:'420px', height:'24px', borderRadius:'9999px', background:'rgba(255,255,255,.1)', display:'flex', alignItems:'center', padding:'0 12px', gap:'8px', color:'#8FB6C2', fontSize:'12px'}}><span style={{fontSize:'12px', display:'inline-flex', lineHeight:'0'}}><Icon name="lock" /></span>manage.zoustec.tw/ar-studio</div>
    </div>
    <div style={{height:'60px', background:'#fff', borderBottom:'1px solid var(--border-subtle)', display:'flex', alignItems:'center', padding:'0 22px', gap:'12px'}}>
      <span style={{width:'34px', height:'34px', borderRadius:'9px', background:'linear-gradient(145deg,#6FCDE8,#0E7490)', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'17px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="sparkles" /></span></span>
      <div><div style={{fontSize:'15px', fontWeight:'800', color:'var(--text-strong)'}}>AR Studio · 建立 3D 模型</div><div style={{fontSize:'11.5px', color:'var(--text-muted)'}}>吉祥物「赤崁小龜」</div></div>
      <div style={{marginLeft:'auto', display:'flex', gap:'10px'}}>
        <div style={{display:'flex', alignItems:'center', gap:'7px', height:'36px', padding:'0 13px', borderRadius:'8px', border:'1px solid var(--border-default)', color:'var(--text-body)', fontSize:'13px', fontWeight:'600'}}><span style={{fontSize:'15px', display:'inline-flex', lineHeight:'0'}}><Icon name="refresh-cw" /></span>重新生成</div>
        <div style={{display:'flex', alignItems:'center', gap:'7px', height:'36px', padding:'0 15px', borderRadius:'8px', background:'var(--primary-600)', color:'#fff', fontSize:'13px', fontWeight:'600'}}><span style={{fontSize:'15px', display:'inline-flex', lineHeight:'0'}}><Icon name="scan-line" /></span>匯出至 WebAR</div>
      </div>
    </div>

    <div style={{display:'flex', height:'720px', background:'var(--surface-sunken)'}}>
      
      <aside style={{width:'300px', flex:'0 0 auto', background:'#fff', borderRight:'1px solid var(--border-subtle)', padding:'20px 18px', overflow:'auto'}}>
        <div style={{fontSize:'11px', fontWeight:'700', letterSpacing:'.08em', textTransform:'uppercase', color:'var(--text-subtle)', marginBottom:'11px'}}>1 · 2D 來源圖</div>
        <div style={{border:'1px solid var(--border-subtle)', borderRadius:'12px', overflow:'hidden', marginBottom:'8px'}}><div style={{height:'150px', background:'linear-gradient(135deg,#D0F1FB,#A6E3F5)', display:'flex', alignItems:'center', justifyContent:'center', position:'relative'}}><span style={{fontSize:'64px', color:'var(--primary-700)', opacity:'.85', display:'inline-flex', lineHeight:'0'}}><Icon name="image" /></span><span style={{position:'absolute', bottom:'8px', left:'8px', fontSize:'10.5px', fontWeight:'600', background:'rgba(11,41,53,.7)', color:'#fff', padding:'3px 8px', borderRadius:'9999px', fontFamily:'var(--font-mono)'}}>chihkan-turtle.png</span></div></div>
        <div style={{display:'flex', alignItems:'center', justifyContent:'center', gap:'7px', padding:'9px', borderRadius:'8px', border:'1.5px dashed var(--border-default)', color:'var(--text-muted)', fontSize:'12.5px', fontWeight:'600', marginBottom:'20px'}}><span style={{fontSize:'15px', display:'inline-flex', lineHeight:'0'}}><Icon name="image-up" /></span>更換來源圖</div>
        <div style={{fontSize:'11px', fontWeight:'700', letterSpacing:'.08em', textTransform:'uppercase', color:'var(--text-subtle)', marginBottom:'11px'}}>2 · 描述（選填）</div>
        <div style={{border:'1px solid var(--border-default)', borderRadius:'9px', padding:'11px', fontSize:'12.5px', color:'var(--text-body)', lineHeight:'1.5', background:'var(--surface-sunken)', marginBottom:'20px'}}>馱著御龜碑的小龜，可愛卡通風格，青瓷色調，陶瓷釉面材質。</div>
        <div style={{fontSize:'11px', fontWeight:'700', letterSpacing:'.08em', textTransform:'uppercase', color:'var(--text-subtle)', marginBottom:'11px'}}>3 · 細緻度</div>
        <div style={{display:'flex', gap:'7px'}}>
          <span style={{flex:'1', textAlign:'center', padding:'9px', borderRadius:'8px', fontSize:'12px', fontWeight:'600', color:'var(--text-muted)', background:'var(--surface-sunken)'}}>低</span>
          <span style={{flex:'1', textAlign:'center', padding:'9px', borderRadius:'8px', fontSize:'12px', fontWeight:'700', color:'#fff', background:'var(--primary-600)'}}>標準</span>
          <span style={{flex:'1', textAlign:'center', padding:'9px', borderRadius:'8px', fontSize:'12px', fontWeight:'600', color:'var(--text-muted)', background:'var(--surface-sunken)'}}>高</span>
        </div>
        <div style={{fontSize:'11px', color:'var(--text-subtle)', marginTop:'8px', lineHeight:'1.45'}}>簡化版本，最佳化於行動裝置 WebAR。</div>
      </aside>

      
      <div style={{flex:'1', minWidth:'0', display:'flex', flexDirection:'column', position:'relative', background:'radial-gradient(circle at 50% 40%,#134E61,#0B2935)'}}>
        <div style={{position:'absolute', top:'16px', left:'50%', transform:'translateX(-50%)', display:'flex', alignItems:'center', gap:'8px', background:'rgba(255,255,255,.1)', border:'1px solid rgba(255,255,255,.14)', padding:'7px 13px', borderRadius:'9999px', color:'#D0F1FB', fontSize:'12px', fontWeight:'600', backdropFilter:'blur(6px)'}}><span style={{width:'7px', height:'7px', borderRadius:'50%', background:'var(--success-500)'}}></span>已生成模型 · GLB 3D</div>
        <div style={{flex:'1', display:'flex', alignItems:'center', justifyContent:'center'}}>
          <div style={{position:'relative', width:'280px', height:'280px', display:'flex', alignItems:'center', justifyContent:'center'}}>
            <div style={{position:'absolute', width:'280px', height:'280px', borderRadius:'50%', background:'radial-gradient(circle,rgba(56,176,214,.25),transparent 68%)'}}></div>
            <div style={{position:'absolute', bottom:'30px', width:'180px', height:'34px', borderRadius:'50%', background:'rgba(0,0,0,.35)', filter:'blur(9px)'}}></div>
            <div style={{width:'190px', height:'190px', borderRadius:'34px', background:'linear-gradient(150deg,#38B0D6,#0E7490)', boxShadow:'0 30px 60px rgba(0,0,0,.4),inset 0 3px 14px rgba(255,255,255,.35)', display:'flex', alignItems:'center', justifyContent:'center', transform:'rotate(-8deg)'}}><span style={{fontSize:'104px', color:'rgba(255,255,255,.92)', display:'inline-flex', lineHeight:'0', transform:'rotate(8deg)'}}><Icon name="box" /></span></div>
            <span style={{position:'absolute', top:'14px', right:'16px', width:'40px', height:'40px', borderRadius:'9999px', background:'rgba(255,255,255,.14)', border:'1px solid rgba(255,255,255,.2)', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'18px', backdropFilter:'blur(6px)'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="rotate-3d" /></span></span>
          </div>
        </div>
        <div style={{height:'56px', flex:'0 0 auto', display:'flex', alignItems:'center', justifyContent:'center', gap:'10px', borderTop:'1px solid rgba(255,255,255,.08)'}}>
          <span style={{width:'40px', height:'40px', borderRadius:'9999px', background:'rgba(255,255,255,.1)', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'17px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="rotate-3d" /></span></span>
          <span style={{width:'40px', height:'40px', borderRadius:'9999px', background:'rgba(255,255,255,.1)', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'17px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="maximize" /></span></span>
          <span style={{width:'40px', height:'40px', borderRadius:'9999px', background:'rgba(255,255,255,.1)', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'17px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="play" /></span></span>
        </div>
      </div>

      
      <aside style={{width:'300px', flex:'0 0 auto', background:'#fff', borderLeft:'1px solid var(--border-subtle)', padding:'20px 18px', overflow:'auto'}}>
        <div style={{fontSize:'13px', fontWeight:'800', color:'var(--text-strong)', marginBottom:'16px'}}>調整</div>
        <div style={{fontSize:'12px', fontWeight:'600', color:'var(--text-body)', marginBottom:'9px'}}>主色調</div>
        <div style={{display:'flex', gap:'9px', marginBottom:'20px'}}>
          <span style={{width:'34px', height:'34px', borderRadius:'9999px', background:'#0E7490', boxShadow:'0 0 0 2px #fff,0 0 0 4px var(--primary-600)'}}></span>
          <span style={{width:'34px', height:'34px', borderRadius:'9999px', background:'#16A34A'}}></span>
          <span style={{width:'34px', height:'34px', borderRadius:'9999px', background:'#D97706'}}></span>
          <span style={{width:'34px', height:'34px', borderRadius:'9999px', background:'#7C3AED'}}></span>
          <span style={{width:'34px', height:'34px', borderRadius:'9999px', background:'#DC2626'}}></span>
        </div>
        <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:'9px'}}><span style={{fontSize:'12px', fontWeight:'600', color:'var(--text-body)'}}>比例</span><span style={{fontSize:'12px', fontWeight:'700', color:'var(--primary-600)', fontFamily:'var(--font-mono)'}}>1.4×</span></div>
        <div style={{height:'6px', borderRadius:'9999px', background:'var(--surface-sunken)', position:'relative', marginBottom:'20px'}}><span style={{position:'absolute', left:'0', top:'0', height:'6px', width:'62%', borderRadius:'9999px', background:'var(--primary-600)'}}></span><span style={{position:'absolute', left:'62%', top:'50%', transform:'translate(-50%,-50%)', width:'18px', height:'18px', borderRadius:'50%', background:'#fff', boxShadow:'var(--shadow-md)', border:'2px solid var(--primary-600)'}}></span></div>
        <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:'9px'}}><span style={{fontSize:'12px', fontWeight:'600', color:'var(--text-body)'}}>表面光澤</span><span style={{fontSize:'12px', fontWeight:'700', color:'var(--primary-600)', fontFamily:'var(--font-mono)'}}>70%</span></div>
        <div style={{height:'6px', borderRadius:'9999px', background:'var(--surface-sunken)', position:'relative', marginBottom:'22px'}}><span style={{position:'absolute', left:'0', top:'0', height:'6px', width:'70%', borderRadius:'9999px', background:'var(--primary-600)'}}></span><span style={{position:'absolute', left:'70%', top:'50%', transform:'translate(-50%,-50%)', width:'18px', height:'18px', borderRadius:'50%', background:'#fff', boxShadow:'var(--shadow-md)', border:'2px solid var(--primary-600)'}}></span></div>
        <div style={{borderTop:'1px solid var(--border-subtle)', paddingTop:'16px', fontSize:'11px', fontWeight:'700', letterSpacing:'.08em', textTransform:'uppercase', color:'var(--text-subtle)', marginBottom:'12px'}}>匯出格式</div>
        <div style={{display:'flex', alignItems:'center', gap:'11px', padding:'12px', borderRadius:'10px', border:'1.5px solid var(--primary-600)', background:'var(--primary-50)', marginBottom:'9px'}}><span style={{width:'32px', height:'32px', borderRadius:'8px', background:'var(--primary-600)', color:'#fff', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'16px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="scan-line" /></span></span><div style={{flex:'1'}}><div style={{fontSize:'12.5px', fontWeight:'700', color:'var(--primary-800)'}}>WebAR (GLB + USDZ)</div><div style={{fontSize:'11px', color:'var(--primary-700)'}}>最佳化行動裝置</div></div><span style={{color:'var(--primary-600)', fontSize:'16px', display:'inline-flex', lineHeight:'0'}}><Icon name="circle-check" /></span></div>
        <div style={{display:'flex', alignItems:'center', gap:'11px', padding:'12px', borderRadius:'10px', border:'1px solid var(--border-subtle)'}}><span style={{width:'32px', height:'32px', borderRadius:'8px', background:'var(--surface-sunken)', color:'var(--text-muted)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:'16px'}}><span style={{display:'inline-flex', lineHeight:'0'}}><Icon name="download" /></span></span><div style={{flex:'1'}}><div style={{fontSize:'12.5px', fontWeight:'700', color:'var(--text-strong)'}}>下載原始檔</div><div style={{fontSize:'11px', color:'var(--text-muted)'}}>高解析度 GLB</div></div></div>
      </aside>
    </div>
  </div>
</section>
  );
}
